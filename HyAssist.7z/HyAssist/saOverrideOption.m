%--------------------------------------------------------------------------
%   �� �� ����saOverrideOption.m
%   �ļ�������
%   ��    ����V1.0
%   �޸ļ�¼��
%--------------------------------------------------------------------------
function opt = saOverrideOption( varargin )

    opt = struct;
    for i = nargin: - 1:1
        tmpopt = varargin{ i };
        if ~isstruct( tmpopt )
            continue ;
        end 
        flds = fieldnames( tmpopt );
        for k = 1:numel( flds )
            opt.( flds{ k } ) = tmpopt.( flds{ k } );
        end 
    end 
    
end