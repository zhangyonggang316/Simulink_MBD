classdef saLine < saObject

	properties 
		MajorProperty = 'Name';

		OutportStringMethod = 'Name';
		InportStringMethod = 'Name';

		SetPropertyMethod = 'Name';
	end 

	properties (Constant)
		Dictionary = HY_DICTIONARY;
	end 

	methods 
		function obj = saLine( varargin )
			obj = obj@saObject( 'line' );
			obj.MapKey = 'line';
		end 
    end
    
end 
