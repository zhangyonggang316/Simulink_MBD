function majprop = GetMajorProperty( obj, LineHndl )
    majprop = 'Name';
end