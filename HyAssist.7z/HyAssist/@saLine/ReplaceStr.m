function actrec = ReplaceStr( obj, lnhdl, oldstr, newstr )

    actrec = saRecorder;
    nam = get_param( lnhdl, 'Name' );
    if isempty( nam )
        return ;
    end 
    if strcmp( oldstr, '^' )
        newnam = [ newstr, nam ];
    elseif strcmp( oldstr, '$' )
        newnam = [ nam, newstr ];
    else 
        newnam = regexprep( nam, oldstr, newstr );
    end 
    actrec.SetParam( lnhdl, 'Name', newnam );
end