function actrec = SetProperty( obj, LineHndl, PropVal, ~ )
    actrec = saRecorder;
    actrec.SetParam( LineHndl, 'Name', PropVal );
end