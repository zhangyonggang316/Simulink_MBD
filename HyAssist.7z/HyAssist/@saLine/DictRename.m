function actrec = DictRename( obj, BlkHndl )
    actrec = saRecorder;
    nam = get_param( BlkHndl, 'Name' );
    newnam = saDictRenameString( nam, obj.Dictionary );
    actrec.SetParam( BlkHndl, 'Name', newnam );
end