%--------------------------------------------------------------------------
%   �� �� ����findInCell.m
%   �ļ�������Cellѭ������
%   �޸ļ�¼��
%            2021/08/22    ���轭      �½��ļ�
%--------------------------------------------------------------------------
function y = findInCell( var, cellArray, s )

    y = [  ];

    for i = 1:numel( cellArray )
        if iscell( cellArray{ i } ) && ~isempty( cellArray{ i } )
            y = [ y, findInCell( var, cellArray{ i }, [ s, subs( i, size( cellArray ) ) ] ) ];
        else 
            if strcmp( var, cellArray{ i } )
                y = [ s, subs( i, size( cellArray ) ) ];
                break 
            end 
        end 
    end 
end 

function s = subs( i, siz )

    if length( siz ) == 2 && any( any( siz == 1 ) )
        v = cell( 1, 1 );
    else 
        v = cell( size( siz ) );
    end 
    [ v{ 1:end  } ] = ind2sub( siz, i );

    s = [ '{', int2str( v{ 1 } ) ];
    
    for i = 2:length( v )
        s = [ s, ',', int2str( v{ i } ) ];
    end 
    s = [ s, '}' ];
end 
