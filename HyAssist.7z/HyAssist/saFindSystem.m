%--------------------------------------------------------------------------
%   �� �� ����saFindSystem.m
%   �ļ�����������ѡ��ģ�����
%   ��    ����V1.0
%   �޸ļ�¼��
%--------------------------------------------------------------------------
function varargout = saFindSystem( rtSys, Type, Option, varargin )
    
    if nargin < 1 || isempty( rtSys )   %δ���������ǰϵͳΪ��ʱ���趨����·��Ϊ��ǰ����·��
        rtSys = gcs;
    end 
    if nargin < 2 || isempty( Type )    % �޲�������ʱ��Ĭ����������
        Type = 'all';
    end 
    if nargin < 3 || isempty( Option )  % �޲��Ҿ���ѡ��ʱ��Ĭ�ϵ�ǰ�㼶��������̽����װ���Ҳ���Բ���
        Option = { 'SearchDepth', 1, 'FollowLinks', 'on', 'LookUnderMasks', 'on', 'FindAll', 'on' };
    end 

    switch Type
        case 'block'
            Hndls = find_system( rtSys, Option{ : }, 'Type', 'block', 'Selected', 'on', varargin{ : } );
            Hndls = setdiff( Hndls, get_param( rtSys, 'Handle' ) );
        case 'line'
            Hndls = find_system( rtSys, Option{ : }, 'Type', 'line', 'Selected', 'on', varargin{ : } );
            Hndls = saRemoveBranchLine( Hndls );
        case 'block&line'
            Lines = saFindSystem( rtSys, 'line' );
            Blks = saFindSystem( rtSys, 'block' );
            Hndls = [ Blks;Lines ];
        case 'line_unconnected'
            hdls1 = find_system( rtSys, Option{ : }, 'Type', 'line', 'Selected', 'on', 'SrcPortHandle', -1, varargin{ : } );
            hdls2 = find_system( rtSys, Option{ : }, 'Type', 'line', 'Selected', 'on', 'DstPortHandle', -1, varargin{ : } );
            Hndls = saRemoveBranchLine( [ hdls1;hdls2 ] );
        case 'line_nosrc'
            Hndls = find_system( rtSys, Option{ : }, 'Type', 'line', 'Selected', 'on', 'SrcPortHandle', -1, varargin{ : } );
            Hndls = saRemoveBranchLine( Hndls );
        case 'line_nodst'
            Hndls = find_system( rtSys, Option{ : }, 'Type', 'line', 'Selected', 'on', 'DstPortHandle', -1, varargin{ : } );
            Hndls = saRemoveBranchLine( Hndls );
        case 'port_unconnected'
            Hndls = find_system( rtSys, Option{ : }, 'Type', 'port', 'Line', -1, varargin{ : } );
            Hndls = Port_Filter_Selected( Hndls );
        case 'inport_unconnected'
            Hndls = find_system( rtSys, Option{ : }, 'Type', 'port', 'Line', -1, 'PortType', 'inport', varargin{ : } );
            Hndls = Port_Filter_Selected( Hndls );
        case 'outport_unconnected'
            Hndls = find_system( rtSys, Option{ : }, 'Type', 'port', 'Line', -1, 'PortType', 'outport', varargin{ : } );
            Hndls = Port_Filter_Selected( Hndls );
        case 'unconnected'
            LineHndls = saFindSystem( rtSys, 'line_unconncted', Option, varargin{ : } );
            PortHndls = saFindSystem( rtSys, 'port_unconncted', Option, varargin{ : } );
            Hndls = [ LineHndls;PortHndls ];
        case 'line_receiver'
            uclns = saFindSystem( gcs, 'line_nosrc' );
            ucpts = saFindSystem( gcs, 'inport_unconnected' );
            Hndls = [ uclns;ucpts ];
        case 'line_sender'
            Lines = saFindSystem( rtSys, 'line' );
            ucpts = saFindSystem( rtSys, 'outport_unconnected' );
            Hndls = [ Lines;ucpts ];
        case 'all'
            Hndls = find_system( rtSys, 'SearchDepth', 1, 'LookUnderMasks', 'on', 'FollowLinks', 'on', 'FindAll', 'on', 'Selected', 'on', varargin{ : } );
            Hndls = setdiff( Hndls, get_param( rtSys, 'Handle' ) );
        otherwise 
    end 
    varargout{ 1 } = Hndls;
end 


function hdls = Port_Filter_Selected( hdls, rtsys )

    if nargin < 2
        rtsys = gcs;
    end 
    if isempty( hdls )
        hdls = [  ];
        return ;
    end 
    parblks = get_param( hdls, 'Parent' );
    if iscell( parblks )
        f1 = strcmp( get_param( parblks, 'Selected' ), 'on' );
        f2 = cell2mat( get_param( parblks, 'Handle' ) ) ~= get_param( rtsys, 'Handle' );
        hdls = hdls( f1 & f2 );
    else 
        if strcmp( get_param( parblks, 'Selected' ), 'on' ) && ( get_param( parblks, 'Handle') ~= get_param( rtsys, 'Handle' ) )
        else 
            hdls = [  ];
        end 
    end 
end