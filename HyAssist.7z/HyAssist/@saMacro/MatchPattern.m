function objs = MatchPattern( objarr, cmdstr )

    Patterns = { objarr.Pattern }';
    idxm = cellfun( @( c )~isempty( regexp( cmdstr, c ) ), Patterns );
    objs = objarr( idxm );

end