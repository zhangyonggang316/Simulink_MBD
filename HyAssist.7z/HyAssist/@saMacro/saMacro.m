classdef saMacro < handle

    properties 
		Name = ''
		Pattern = ''
		PromptMethod
		Callback
		Type = ''
		Priority = 50;
		Console
	end 

	methods 
		function obj = saMacro( varargin )
			if ischar( varargin{ 1 } )
				obj.Name = varargin{ 1 };
			end 
		end 

		function set.Pattern( obj, val )
			obj.Pattern = val;
			if isempty( obj.PromptMethod )
				if val( 1 ) == '^'
					val( 1 ) = '';
				end 
				prompts = regexp( val, '\|', 'split' );
				prompts = regexprep( prompts, '(^\()|(\)$)', '' );
				obj.PromptMethod = prompts;
			end 
		end 
	end 
end 