function [ actrec, success ] = Run( objarr, cmdstr )
    if nargin < 2
        cmdstr = '';
    end 
    console = objarr( 1 ).Console;
    for i = 1:numel( objarr )
        theobj = objarr( i );
        ni = nargin( theobj.Callback );
        if ni > 2
            [ args{ 1:ni - 2 } ] = theobj.Parse( cmdstr, console );
        else 
            args = {  };
        end 
        arglist = { cmdstr, console, args{ : } };
        [ actrec, success ] = theobj.Callback( arglist{ 1:ni } );
        if success
            break ;
        end 
    end 
end