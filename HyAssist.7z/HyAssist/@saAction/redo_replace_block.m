function redo_replace_block( obj )
    BlkTyp = get_param( obj.Data.Path, 'BlockType' );
    BlkHndl = replace_block( obj.Data.Path, BlkTyp, obj.Data.NewBlockSrc, 'noprompt' );
    if iscell( BlkHndl )
        BlkHndl = BlkHndl{ 1 };
    end 
    obj.Handle = get_param( BlkHndl, 'Handle' );
end