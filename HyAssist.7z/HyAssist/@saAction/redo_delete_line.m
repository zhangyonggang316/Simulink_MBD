function redo_delete_line( obj )
obj.delete_line( obj.Handle );
end 
