function add_line( obj, sys, varargin )
    if isempty( sys )
        sys = gcs;
    end 
    name = '';
    
    if size( varargin{ 1 }, 2 ) == 2
        LinePos = varargin{ 1 };
        LineHndl = add_line( sys, LinePos );
        if numel( varargin ) > 1
            name = varargin{ 2 };
        end 
        try 
            set_param( LineHndl, 'Name', name );
        catch
            %��ʱ�����κδ���
        end 
    else 
        [ pt1, pt2 ] = deal( varargin{ 1:2 } );
        LineHndl = add_line( sys, pt1, pt2, 'autorouting', 'on' );
        LinePos = get_param( LineHndl, 'Points' );
        if numel( varargin ) > 2
            name = varargin{ 3 };
        end
        
        try 
            set_param( LineHndl, 'Name', name );
        catch
            %��ʱ�����κδ���
        end 
    end 
    obj.Property = { 'Name', name };
    obj.Data.System = sys;
    obj.Data.Points = LinePos;
    obj.Handle = LineHndl;
end