%-------------------------------------------------------------------------------------------
%   �� �� ����Redo.m
%   �ļ��������ָ������ű�
%   ��    ����V1.1.0
%   �޸ļ�¼��
%            2022/08/01    xuhongjiang01    1�����ӻָ�set��������
%-------------------------------------------------------------------------------------------
function echo = Redo( obj )
    echo = [  ];
    switch obj.Type
        case 'set'
            obj.redo_set;
        case 'set_param'
            obj.redo_set_param;
        case 'set_param_stateflow'
            obj.redo_set_param_stateflow;
        case 'add_block'
            echo.OldHandle = obj.Handle;
            obj.redo_add_block;
            echo.NewHandle = obj.Handle;
        case 'add_line'
            obj.redo_add_line;
        case 'delete_line'
            obj.redo_delete_line;
        case 'replace_block'
            echo.OldHandle = obj.Handle;
            obj.redo_replace_block;
            echo.NewHandle = obj.Handle;
        otherwise 
    end 
end 
