function [ actrec, success ] = multiprop( btobj, cmdstr, pattern, varargin )


actrec = saRecorder;success = false;

cmdpsr = saCmdParser( cmdstr, pattern );
[ vals, bclean ] = cmdpsr.ParseMultiValues;
if ~bclean
[ actrec, success ] = deal( saRecorder, false );return ;
end 

propdef = btobj.MajorProperty;
pvpair = varargin;option = struct;
if isempty( vals )
elseif numel( vals ) == 1
for i = 1:size( propdef, 1 )
if isstr( propdef{ i, 2 } )
pvpair = [ pvpair, propdef{ i, 1 }, strcat( vals{ 1 }, propdef{ i, 2 } ) ];
else 
fh = propdef{ i, 2 };
pvpair = [ pvpair, propdef{ i, 1 }, fh( vals{ 1 } ) ];
end 
end 
option.PropagateString = false;
else 
for i = 1:numel( vals )
pvpair = [ pvpair, propdef{ i, 1 }, vals{ i } ];
end 
option.PropagateString = false;
end 
actrec + btobj.GenericContextAdd( pvpair{ : }, option );
success = true;
end 
% Decoded using De-pcode utility v1.2 from file /tmp/tmpsbvifY.p.
% Please follow local copyright laws when handling this file.

