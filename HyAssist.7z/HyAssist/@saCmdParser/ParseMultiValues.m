function [ vals, bclean ] = ParseMultiValues( obj, nmax )

    if nargin < 2
        nmax = inf;
    end
    
    if isempty( obj.OptionStr )
        result = {  };
    else 
        result = regexp( obj.OptionStr, '(?<!\[.*)(,|\s)+(?!.*\])', 'split' );
    end
    
    if ~isempty( result ) && isempty( result{ end  } )
        result( end  ) = [  ];
    end
    
    vals = {  };
    for i = 1:numel( result )
        vals = [ vals, obj.ParseSeqExpr( result{ i } ) ];
    end
    
    if nargin > 1 && numel( vals ) > nmax
        bclean = false;
    else 
        bclean = true;
    end 
end