function [ result, bclean ] = ParseSingleValue( obj )
    result = obj.OptionStr;
    bclean = true;
end