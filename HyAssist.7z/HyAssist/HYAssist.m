%-------------------------------------------------------------------------------------------
%   �� �� ����HYAssist.m
%   �ļ�������HYAssist���߽ű�
%   ��    ����V1.0.1
%   �޸ļ�¼��
%           2022/06/30    xuhongjiang01    ɾ��license�ж��߼�
%           2022/11/30    xuhongjiang01    �޸�Bus Selector�ź�����߼��������������
%-------------------------------------------------------------------------------------------
function varargout = HYAssist( varargin )

    gui_Singleton = 1;
    gui_State = struct( 'gui_Name', mfilename,  ...
    'gui_Singleton', gui_Singleton,  ...
    'gui_OpeningFcn', @HYAssist_OpeningFcn,  ...
    'gui_OutputFcn', @HYAssist_OutputFcn,  ...
    'gui_LayoutFcn', [  ],  ...
    'gui_Callback', [  ] );
    if nargin && ischar( varargin{ 1 } )
        gui_State.gui_Callback = str2func( varargin{ 1 } );
    end 
    if nargout
        [ varargout{ 1:nargout } ] = gui_mainfcn( gui_State, varargin{ : } );
    else 
        gui_mainfcn( gui_State, varargin{ : } );
    end 

end 


function HYAssist_OpeningFcn( hObject, eventdata, handles, varargin )

    %�Ѿ���һ�����߽���ʱ��ֹ�ٿ��½��棬�����������֮ǰ����Ĳ���
    if isfield( handles, 'GUIOpen' ) && handles.GUIOpen
        uicontrol( handles.edit_cmdstr );
        set( handles.edit_cmdstr, 'String', '' );
        return ;
    end 
    handles.output = hObject;

    handles.GUIOpen = true;
    set( handles.btnUndo, 'Enable', 'off' );
    set( handles.btnRedo, 'Enable', 'off' );
    uicontrol( handles.edit_cmdstr );
    handles.hispointer = 0;

    handles.ExtraDlgParas = { 'AttributesFormatString'; };

    sapath = fileparts( mfilename( 'fullpath' ) );
    addpath( fullfile( sapath, '_BlockRegistration' ) );
    addpath( fullfile( sapath, '_MacroRegistration' ) );
    addpath( fullfile( sapath, 'Dialogs' ) );
    
    handles.Console = saConsole;
    handles.Console.BuildMap;
    handles.Console.BuildMacros;
     
    guidata( hObject, handles );

end 

function edit_contextmenu_callback( hObj, eventdata, handles )
    set( handles.edit_cmdstr, 'String', get( hObj, 'Label' ) );
end 



function varargout = HYAssist_OutputFcn( hObject, eventdata, handles )

    varargout{ 1 } = hObject;
end 



function HYAssist_CloseRequestFcn( hObject, eventdata, handles )

    try 
        if ~isempty( handles.Console.Newer )
            sapath = fileparts( mfilename( 'fullpath' ) );
            buffile = fullfile( sapath, [ '_BlockRegistration\regblock_custom', datestr( now, 'yyyymmddHHMMSS' ) ] );
            newer = handles.Console.Newer;
            save( buffile, 'newer' );
        end 

        SAVEONCLOSE = false;
        if isfield( handles, 'Console' ) && SAVEONCLOSE
            sapath = fileparts( mfilename( 'fullpath' ) );
            buffile = fullfile( sapath, 'HYAssistBuffer.mat' );
            save( buffile, '-struct', 'handles', 'Console' );
        end 
        delete( hObject );
    catch 
        delete( hObject );
    end 
end 


%--------------------------------------------------------------------------
%   �� �� ����savehistory( handles, actrec )
%   ����������������ʷ���洢��������
%   �޸ļ�¼��
%--------------------------------------------------------------------------
function savehistory( handles, actrec )
    
    hisdata = get(handles.HYAssist, 'UserData');
    if handles.hispointer >= 1
        hisdata = hisdata(1:handles.hispointer);
    else 
        hisdata = [  ];
    end 
    hisdata = [hisdata;actrec];
    handles.hispointer = handles.hispointer + 1;
    set(handles.HYAssist,'UserData',hisdata);
    set(handles.btnUndo,'Enable','on');
    set(handles.btnRedo,'Enable','off');
    guidata(handles.HYAssist,handles);
    
end 


%--------------------------------------------------------------------------
%   �� �� ����PinOnTop_ClickedCallback( hObject, eventdata, handles )
%   ���������������ö���ť�ص�
%   �޸ļ�¼��
%--------------------------------------------------------------------------
function PinOnTop_ClickedCallback( hObject, eventdata, handles )

    tmp = get( hObject, 'CData' );
    set(hObject,'CData',get(hObject,'UserData'));
    set(hObject,'UserData',tmp);

    warning('off','MATLAB:HandleGraphics:ObsoletedProperty:JavaFrame');
    fJFrame = get(handles.HYAssist,'JavaFrame');
    if verLessThan('matlab','7.10')
        figclient = 'fFigureClient';
    elseif verLessThan('matlab','8.4')
        figclient = 'fHG1Client';
    else 
        figclient = 'fHG2Client';
    end 

    if strcmpi(get( hObject,'State'),'on')
        fJFrame.(figclient).getWindow.setAlwaysOnTop(1);
    else 
        fJFrame.(figclient).getWindow.setAlwaysOnTop(0);
    end 
    warning('on','MATLAB:HandleGraphics:ObsoletedProperty:JavaFrame');
end 


%--------------------------------------------------------------------------
%   �� �� ����btnUndo_ClickedCallback( hObject, eventdata, handles )
%   ����������������ť�ص�
%   �޸ļ�¼��
%--------------------------------------------------------------------------
function btnUndo_ClickedCallback( hObject, eventdata, handles )

    hisdata = get(handles.HYAssist,'UserData');
    actrec = hisdata(handles.hispointer);
    actrec.Undo;
    handles.hispointer = handles.hispointer - 1;
    set(handles.btnRedo,'Enable','on');
    
    if handles.hispointer == 0
        set(hObject,'Enable','off');
    end
    
    guidata(handles.HYAssist,handles);
end 


%--------------------------------------------------------------------------
%   �� �� ����btnRedo_ClickedCallback( hObject, eventdata, handles )
%   ����������������ť�ص�
%   �޸ļ�¼��
%--------------------------------------------------------------------------
function btnRedo_ClickedCallback( hObject, eventdata, handles )

    hisdata = get(handles.HYAssist,'UserData');
    handles.hispointer = handles.hispointer + 1;
    actrec = hisdata(handles.hispointer);
    actrec.Redo;
    set(handles.btnUndo,'Enable','on');
    if handles.hispointer == numel(hisdata)
        set(hObject,'Enable','off');
    end 
    guidata(handles.HYAssist,handles);
    
    set(handles.HYAssist,'UserData',hisdata);
end


%--------------------------------------------------------------------------
%   �� �� ����SrcPropagate_Callback(hObject,eventdata,handles)
%   ����������Դ���ݼ̳а�ť�ص�
%   �޸ļ�¼��
%--------------------------------------------------------------------------
function SrcPropagate_Callback(hObject,eventdata,handles)

    actrec = saRecorder;
    objs = saFindSystem(gcs,'block&line');
    if isempty(objs)
        return ;
    end 
    objs = saRemoveBranchLine(objs);
    for i = 1:numel(objs)
        sabt = handles.Console.MapTo(objs(i));
        if ~isempty(sabt)
            actrec.Merge(sabt.PropagateUpstreamString(objs(i)));
            if sabt.isa('block') && ~any(xor(sabt.ConnectPort,[0,1]))
                actrec.Merge(sabt.CreateBroBlock(objs(i)));
            end 
        else 
            continue ;
        end 
    end 
    savehistory(handles,actrec);
end 

%--------------------------------------------------------------------------
%   �� �� ����DstPropagate_Callback(hObject,eventdata,handles)
%   ����������Ŀ�괫�ݼ̳а�ť�ص�
%   �޸ļ�¼��
%--------------------------------------------------------------------------
function DstPropagate_Callback(hObject,eventdata,handles)

    actrec = saRecorder;
    objs = saFindSystem(gcs,'block&line');
    if isempty(objs)
        return ;
    end 
    objs = saRemoveBranchLine(objs);
    for i = 1:numel(objs)
        sabt = handles.Console.MapTo(objs(i));
        if ~isempty(sabt)
            actrec.Merge(sabt.PropagateDownstreamString(objs(i)));
            if sabt.isa('block') && ~any(xor(sabt.ConnectPort,[1,0]))
                actrec.Merge(sabt.CreateBroBlock(objs(i)));
            end 
        else 
            continue ;
        end 
    end 
    savehistory(handles,actrec);
end


%--------------------------------------------------------------------------
%   �� �� ����btn_align_Callback(hObject,eventdata,handles)
%   �������������밴ť�ص�
%   �޸ļ�¼��
%--------------------------------------------------------------------------
function btn_align_Callback(hObject,eventdata,handles)

    actrec = saRecorder;
    Blks = saFindSystem(gcs,'block');
    Lines = saFindSystem(gcs,'line');
    if numel(Blks) == 1
        actrec.LayoutAroundBlock(Blks);
    else 
        bg = saBlockGroup(Blks);
        subbgs = bg.SplitToIntactBGs;
        actrec.Merge(bg.AlignPortsInside);
        actrec.Merge(bg.StraightenLinesInside);
        if ~isempty(subbgs)
            actrec.Merge(subbgs.AlignPortsOutside);
        end 
        actrec.Merge(bg.VerticalAlign);
    end
    
    for i = 1:numel(Lines)
        actrec.NeatenLine(Lines(i),'auto');
    end 
    savehistory(handles,actrec);
end 

%--------------------------------------------------------------------------
%   �� �� ����btn_align_ButtonDownFcn(hObject,eventdata,handles)
%   �������������밴ť����갴�»ص�
%   �޸ļ�¼��
%--------------------------------------------------------------------------
function btn_align_ButtonDownFcn(hObject,eventdata,handles)
    actrec = saRecorder;
    objs = saFindSystem(gcs,'block');
    for i = 1:numel(objs)
        actrec.FitSize(objs(i));
        actrec.LayoutAroundBlock(objs(i));
    end 
    savehistory(handles,actrec);
end 


%--------------------------------------------------------------------------
%   �� �� ����AutoAct_Callback(hObject,eventdata,handles)
%   �����������Զ�������ť�ص�
%   �޸ļ�¼��
%--------------------------------------------------------------------------
function AutoAct_Callback(hObject,eventdata,handles)

    actrec = saRecorder;
    blks = saFindSystem(gcs,'block');
    if isempty(blks)
        return;
    end 
    for i = 1:numel(blks)
        sabt = handles.Console.MapTo(blks(i));
        %����ѭ��
        if ~isempty(sabt.RollPropertyMethod)
            actrec.Merge(sabt.RollProperty(blks(i)));
        end
        %ע������
        if ~isempty(sabt.AnnotationMethod)
            actrec.Merge(sabt.Annotate(blks(i)));
        end
        %ģ�����
        if ~isempty(sabt.RefineMethod)
            actrec.Merge(sabt.Refine(blks(i)));
        end
        %�Զ������ߴ�
        if ~isempty(sabt.AutoSizeMethod)
            actrec.Merge(sabt.AutoSize(blks(i)));
        end 
    end 
    savehistory(handles,actrec);
end


%--------------------------------------------------------------------------
%   �� �� ����btn_fmtbrush_Callback(hObject,eventdata,handles)
%   ������������ʽˢ��ť�ص�
%   �޸ļ�¼��
%--------------------------------------------------------------------------
function btn_fmtbrush_Callback(hObject,eventdata,handles)

    ud = get(hObject,'UserData');
    if (isfield(ud,'Handle') && ~isempty(ud.Handle)) || (isfield(ud,'MultiValues') && ~isempty(ud.MultiValues))
        if (isfield(ud,'Handle') && ~isempty(ud.Handle))
            actrec = fmtbrush_brush(hObject,handles);
        else 
            actrec = fmtbrush_multibrush(hObject,handles);
        end 
        savehistory(handles,actrec);

        if strcmp(get(handles.mi_fmt_brushlock,'Checked'),'off')
            ud.Handle = [ ];
            ud.Properties = { };
            ud.MultiValues = { };

            set( hObject, 'CData', ud.CData );
            set( hObject, 'TooltipString', 'ģ�����Ը�ʽˢ' );
            set( hObject, 'UserData', ud );
            set( hObject, 'String', '' );
        end 
    else 
        fmtbrush_buffer( hObject, handles );
    end 
end


%--------------------------------------------------------------------------
%   �� �� ����fmtbrush_buffer(hObject,handles)
%   ������������ʽˢ���溯��
%   �޸ļ�¼��
%--------------------------------------------------------------------------
function fmtbrush_buffer( hObject, handles )
    ud = get(hObject,'UserData');
    fmtblk = saFindSystem(gcs,'block');
    fmtlns = saFindSystem(gcs,'line');
    
    if numel(fmtblk) > 1 || numel(fmtlns) > 0
        set(hObject,'CData',ud.CData2);
        set(hObject,'TooltipString','Multi mode');
        srcobjs = [fmtblk;fmtlns];
        for i = 1:numel(srcobjs)
            btobj = handles.Console.MapTo(srcobjs(i));
            ud.MultiValues{i} = get_param(srcobjs(i), btobj.GetMajorProperty(srcobjs(i)));
        end 
    elseif numel(fmtblk) == 0
        %�����κβ���
    else 
        ud.Handle = fmtblk;
        ud.Properties = { };

        set(hObject,'CData',ud.CData1);
        set(hObject,'TooltipString', ['ģ��ģ��: ', getfullname(fmtblk)]);
    end 
    set(hObject,'UserData',ud);
end

%--------------------------------------------------------------------------------------
%   �� �� ����fmtbrush_brush(hObject,handles)
%   ������������ʽˢ��������
%   �޸ļ�¼��
%             2022/05/17    xuhongjiang01    �޸�ע�͸�ʽˢ��Ҫ����ͬģ�����Ͳſ���ˢע��
%--------------------------------------------------------------------------------------
function actrec = fmtbrush_brush( hObject, handles )
    actrec = saRecorder;
    UserData = get(hObject, 'UserData');
    TarBlks = saFindSystem(gcs, 'block');
    f_getparas = @(blkhdl)fieldnames(get_param(blkhdl, 'DialogParameters'));
    
    RefBklType = get_param(UserData.Handle, 'BlockType');
    
    %Dialog Parameter �˵���ѡ��
    if strcmp(get(handles.mi_fmt_dlgpara, 'Checked'), 'on')
        if isempty(UserData.Properties)
            TarParas = f_getparas(UserData.Handle);
        else 
            TarParas = UserData.Properties;
        end 
        for i = 1:numel(TarBlks)
            thisparas = f_getparas(TarBlks(i));
            sameparas = intersect(thisparas, TarParas);
            sameparavals = cell( 1, numel( sameparas ) );
            for j = 1:numel( sameparas )
                sameparavals{ j } = get_param( UserData.Handle, sameparas{ j } );
            end 
            tmppairs = [ sameparas, sameparavals' ]';
            try 
                actrec.SetParamHighlight( TarBlks( i ), tmppairs{ : } );
            catch
                %��ʱ��������
            end 
        end 
    end
    
    % Color �˵���ѡ�У���ɫ��ʽˢ����ǰ��ɫ���ɫ������ģ�����ʹ��
    if strcmp(get( handles.mi_fmt_color, 'Checked' ), 'on' )
        for i = 1:numel(TarBlks)
            actrec.SetParam(TarBlks(i), 'ForegroundColor', get_param(UserData.Handle, 'ForegroundColor'), ...
                                        'BackgroundColor', get_param(UserData.Handle, 'BackgroundColor'));
        end 
    end
    
    % Size �˵���ѡ��
    if strcmp(get(handles.mi_fmt_size, 'Checked'), 'on')
        RefPos = get_param(UserData.Handle, 'Position');    
        RefSize = RefPos( 3:4 ) - RefPos( 1:2 );              %���ݲο�ģ��λ����Ϣ������ߴ���Ϣ����������ȣ�
        for i = 1:numel( TarBlks )
            if strcmp(RefBklType,get_param(TarBlks(i), 'BlockType'))    %��ͬģ���������������С
                TmpPos = get_param( TarBlks(i), 'Position' );           %��ȡĿ��ģ���λ����Ϣ
                NewPos = [TmpPos( 1:2 ), TmpPos( 1:2 ) + RefSize];      %���ݳ����޸�Ŀ��λ����Ϣ
                actrec.SetParam(TarBlks(i), 'Position', NewPos);
            end
        end 
    end
    
    % Annotation �˵���ѡ��
    if strcmp( get( handles.mi_fmt_anno, 'Checked' ), 'on' )
        for i = 1:numel( TarBlks )
            TarBklType = get_param(TarBlks(i), 'BlockType');
            if strcmp(RefBklType,TarBklType)    %��ͬģ�����Ͳ�����ִ��ע�͸�ʽˢ�޸�
                %��ϵͳ����Ϊ��ͨ��ϵͳ���⣬��װģ�飬chart�ȶ��ֿ��ܣ���Ҫ��������
                if strcmp(TarBklType,'SubSystem')
                    %��ʱ��������ϵͳʹ��ע�͸�ʽˢ
                else
                    actrec.SetParam(TarBlks(i), 'AttributesFormatString', get_param(UserData.Handle, 'AttributesFormatString'));
                end
            end
        end 
    end 
end 


%--------------------------------------------------------------------------
%   �� �� ����fmtbrush_multibrush(hObject,handles)
%   ������������ʽˢ��������
%   �޸ļ�¼��
%--------------------------------------------------------------------------
function actrec = fmtbrush_multibrush( hObject, handles )
    actrec = saRecorder;
    UserData = get(hObject, 'UserData');
    TarBlks = saFindSystem(gcs, 'block');
    TarLines = saFindSystem(gcs, 'line');
    TarObjs = [TarBlks;TarLines];
    for i = 1:numel(TarObjs)
        btobj = handles.Console.MapTo(TarObjs(i));
        MajorProp = btobj.GetMajorProperty(TarObjs(i));
        if ~isempty(MajorProp)
            actrec.SetParamHighlight(TarObjs(i), MajorProp, UserData.MultiValues{ min(i, end) });
        end 
    end 
end 


%--------------------------------------------------------------------------
%   �� �� ����menu_fmtbrush_Callback(hObject, eventdata, handles)
%   ����������fmtbrush�Ҽ��˵��ص�
%   �޸ļ�¼��
%--------------------------------------------------------------------------
function menu_fmtbrush_Callback(hObject, eventdata, handles)


end 


%--------------------------------------------------------------------------
%   �� �� ����mi_fmt_brushlock_Callback(hObject,eventdata,handles)
%   ������������ʽˢ��ť[Hold Brush]�˵��ص�
%   �޸ļ�¼��
%--------------------------------------------------------------------------
function mi_fmt_brushlock_Callback( hObject, eventdata, handles )

    chk = setdiff({'on','off'}, get( hObject, 'Checked' ) );
    set( hObject, 'Checked', chk{ 1 } );
    
end


%--------------------------------------------------------------------------
%   �� �� ����mi_fmt_color_Callback(hObject,eventdata,handles)
%   ������������ʽˢ��ťColor�˵��ص�
%   �޸ļ�¼��
%--------------------------------------------------------------------------
function mi_fmt_color_Callback(hObject, eventdata, handles)

    chk = setdiff({'on','off'}, get( hObject, 'Checked' ) );
    set( hObject, 'Checked', chk{ 1 } );

end


%--------------------------------------------------------------------------
%   �� �� ����mi_fmt_size_Callback(hObject,eventdata,handles)
%   ������������ʽˢ��ťSize�˵��ص�
%   �޸ļ�¼��
%--------------------------------------------------------------------------
function mi_fmt_size_Callback(hObject, eventdata, handles)
    
    chk = setdiff({'on','off'}, get( hObject, 'Checked' ) );
    set( hObject, 'Checked', chk{ 1 } );
    
end


%--------------------------------------------------------------------------
%   �� �� ����mi_fmt_anno_Callback(hObject,eventdata,handles)
%   ������������ʽˢ��ťAnnotation�˵��ص�
%   �޸ļ�¼��
%--------------------------------------------------------------------------
function mi_fmt_anno_Callback(hObject, eventdata, handles)

    chk = setdiff({'on','off'}, get( hObject, 'Checked' ) );
    set( hObject, 'Checked', chk{ 1 } );
    
end


%--------------------------------------------------------------------------
%   �� �� ����mi_fmt_dlgpara_Callback(hObject,eventdata,handles)
%   ������������ʽˢ��ťDialog Parameter�˵��ص�
%   �޸ļ�¼��
%--------------------------------------------------------------------------
function mi_fmt_dlgpara_Callback(hObject, eventdata, handles)
    
    chk = setdiff({'on','off'}, get( hObject, 'Checked' ) );
    set( hObject, 'Checked', chk{ 1 } );
    
end


%--------------------------------------------------------------------------
%   �� �� ����mi_fmt_specify_Callback(hObject,eventdata,handles)
%   ������������ʽˢ��ťSpecify Parameter�˵��ص�
%   �޸ļ�¼��
%--------------------------------------------------------------------------
function mi_fmt_specify_Callback(hObject, eventdata, handles)

    UserData = get( handles.btn_fmtbrush, 'UserData' );
    if isfield( UserData, 'MultiValues' ) && ~isempty( UserData.MultiValues )
        return ;
    end 
    if isfield( UserData, 'Handle' ) && ~isempty( UserData.Handle )
        ListStr = fieldnames( get_param( UserData.Handle, 'DialogParameters' ) );
        if isempty( UserData.Properties )
            InitVal = {  };
        else 
            [Props,ia] = intersect( ListStr, UserData.Properties );
            InitVal = { 'InitialValue', ia };
        end 
        [ Sel, OK ] = listdlg( 'PromptString', 'Select format brush parameters:', 'ListString', ListStr, InitVal{ : } );
        if OK
            UserData.Properties = ListStr( Sel );
            set( handles.btn_fmtbrush, 'UserData', UserData );
        end 
    end 
end 


%--------------------------------------------------------------------------
%   �� �� ����hidename_Callback(hObject,eventdata,handles)
%   ������������ʾ/����ģ�����ư�ť�ص�
%   �޸ļ�¼��
%--------------------------------------------------------------------------
function hidename_Callback(hObject,eventdata,handles)

    actrec = saRecorder;
    
    %��ȡ��ǰ����·�������б�ѡ�е�ģ��
    Blks = find_system(gcs,'SearchDepth',1,'LookUnderMasks','on','FollowLinks','on','Selected','on');
    
    if isempty(Blks)
        return; 
    end
    
    for i = 1:numel(Blks)
        %��ϵͳ�ڲ�ģ��ѡ��ʱ������SubsystemҲΪѡ�У��޳�����ģ��
        if ~strcmpi(Blks{i},gcs)   
            objHndl = get_param(Blks{i},'Handle');
            Property = 'ShowName';
            OldVal = get_param(objHndl,Property);
            if strcmp(OldVal,'off')
                NewVal = 'on';
            else 
                NewVal = 'off';
            end 
            actrec.SetParam(objHndl,Property,NewVal);
        end 
    end 
    savehistory(handles,actrec);
end 


%----------------------------------------------------------------------------------
%   �� �� ����btn_mpt_Callback(hObject,eventdata,handles )
%   �����������źŰ󶨰�ť�ص�
%   �޸ļ�¼��
%             2022/05/17    xuhongjiang01    �޸�Bus Selector����ź�������������
%----------------------------------------------------------------------------------
function btn_mpt_Callback(hObject,eventdata,handles)

    actrec = saRecorder;
    %��ȡ��ǰ����·�������б�ѡ�е�ģ������
    objs = find_system(gcs,'SearchDepth',1,'FindAll','on','LookUnderMasks','on','FollowLinks','on','Selected','on');
    if isempty(objs)
        return;
    end
    
    for i = 1:numel(objs)
        if objs(i) ~= get_param(gcs,'Handle')
            if strcmpi( get_param(objs(i),'Type'),'line')    %ֻ���߲�������
                LineName = get_param(objs(i),'Name');
                
                if isempty(LineName) || ~isempty(regexp(LineName,'[<>]','match'))  %������������������<>ʱ����ֹ��
                    return ;
                end 
                SrcPortHndl = get_param(objs(i),'SrcPortHandle' );
                OldStatus = get_param(SrcPortHndl,'MustResolveToSignalObject');
                %���ݵ�ǰ״̬��ȡ�������
                if strcmpi(OldStatus,'off')
                    actrec.SetParam(SrcPortHndl,'MustResolveToSignalObject','on');
                else 
                    actrec.SetParam(SrcPortHndl,'MustResolveToSignalObject','off');
                end 
            end 
        end 
    end 
    savehistory(handles,actrec);
end 
 

%----------------------------------------------------------------------------------
%   �� �� ����btn_mpt_ButtonDownFcn(hObject,eventdata,handles )
%   �����������źŰ󶨰�ť���ص�
%   �޸ļ�¼��
%             2022/05/17    xuhongjiang01    ���������ڿ������������unname����
%----------------------------------------------------------------------------------
function btn_mpt_ButtonDownFcn(hObject, eventdata, handles)

%     choice = questdlg( '��ȷ��Ҫ���ѡ�е�������?',  ...
%                         '�������',  ...
%                         '���', 'ȡ��', 'ȡ��' );
%     switch choice
%         case '���'
%             uicontrol(handles.edit_cmdstr);
            set(handles.edit_cmdstr, 'String', 'unname');
            uicontrol(handles.edit_cmdstr);
%         case 'ȡ��'
%     end 
    
end


%----------------------------------------------------------------------------------
%   �� �� ����btn_refine_name_Callback(hObject,eventdata,handles )
%   ��������������������ť�ص�
%   �޸ļ�¼��
%----------------------------------------------------------------------------------
function btn_refine_name_Callback( hObject, eventdata, handles )

    actrec = saRecorder;
    if strcmp(get(handles.mi_dictrename_sf, 'Checked'),'on')
        dict = handles.Console.MapTo('Stateflow').Dictionary;
        sfobjs = sfgco;
        renameprops = { 'Name', 'LabelString' };
        for i = 1:numel(sfobjs)
            for k = 1:numel(renameprops)
                if sfobjs(i).isprop(renameprops{k})
                    newvalstr = saDictRenameString(sfobjs(i).(renameprops{k}),dict);
                    actrec.StateflowSetParam(sfobjs(i),renameprops{k},newvalstr);
                end 
            end 
        end 
    else 
        objs = saFindSystem(gcs,'block');
        for i = 1:numel(objs)
            sabt = handles.Console.MapTo(objs(i));
            if ~isempty(sabt.DictRenameMethod)
                actrec.Merge(sabt.DictRename(objs(i)));
            end 
        end 
        lns = saFindSystem(gcs,'line');
        saln = handles.Console.MapTo('line');
        for i = 1:numel(lns)
            actrec.Merge(saln.DictRename(lns(i)));
        end 
    end 
    savehistory(handles,actrec);
end 


%--------------------------------------------------------------------------
%   �� �� ����SelectBusSig_Callback(hObject, eventdata, handles)
%   ����������Bus�ź�ѡ�񰴼��ص�
%   �޸ļ�¼��
%           2022/03/20  xuhongjiang01   �����ص�������ֱ�ӵ��ýű�
%           2022/04/08  xuhongjiang01   ���ű���������ص��У����Ӷ�����¼����
%           2022/11/30  xuhongjiang01   �ſ�Bus�������ƣ��޸��ַ���ƴ�ӷ���
%--------------------------------------------------------------------------
function SelBusSig_Callback(hObject, eventdata, handles)

    actrec = saRecorder;
    BusOption = { 'SearchDepth', 1, 'FollowLinks', 'on', 'FindAll', 'on', 'BlockType','BusSelector' };
    SubSysOption = { 'SearchDepth', 1, 'FollowLinks', 'on',  'FindAll', 'on', 'BlockType','SubSystem' };
    SelBus = saFindSystem( gcs, 'block', BusOption);
    SelSubSys = saFindSystem( gcs, 'block', SubSysOption);
        
    if numel(SelSubSys) > 1
        disp('����ÿ��ֻ��ѡ��һ��SubSystem�����Զ�ѡbus�źŲ���������');
        return;
    end
    
    if isempty(SelBus)
        disp('δѡ���κ�BusSelector������');
        return;
    elseif isempty(SelSubSys)
        disp('δѡ���κ�SubSystem������');
        return;
    end
    
    InportSig = get_param(find_system(SelSubSys(1),'SearchDepth',1,'BlockType','Inport' ),'Name');
    
    for k = 1:numel(SelBus)
        BusSelSig = [  ];
        BusSigCell = get_param(SelBus(k),'InputSignals');
        
        if ~isempty(InportSig)
            for j = 1:numel(InportSig)
                a = findInCell(InportSig(j),BusSigCell,[ ]);
                a1 = strfind(a,'}');
                BusSelSigStr = [];
                for idx=1:2:length(a1)
                    if idx < length(a1)
                        if isempty(BusSelSigStr)
                            BusSelSigStr = strcat(eval(strcat('BusSigCell',a(1:a1(idx)),'{1}')));
                        else
                            BusSelSigStr = [BusSelSigStr,'.',strcat(eval(strcat('BusSigCell',a(1:a1(idx)),'{1}')))];
                        end
                    else
                        if isempty(BusSelSigStr)
                            BusSelSigStr = eval(strcat('BusSigCell',a));
                        else
                            BusSelSigStr = [BusSelSigStr,'.',eval(strcat('BusSigCell',a))];
                        end
                    end
                end
                
                if isempty(BusSelSigStr)
                    % ���ź��ַ���ʱ����׷��
                elseif isempty(BusSelSig)
                    BusSelSig = BusSelSigStr;
                else
                    BusSelSig = [BusSelSig,',',BusSelSigStr];
                end
            end 

            if ~isempty(BusSelSig)
                actrec.SetParam(SelBus(k),'OutputSignals',BusSelSig);
                OutputNo = numel(regexp(BusSelSig,',')) + 1;                     %ͨ��','�ҵ�ƥ���ź�����
                blockPosition = get_param(SelBus(k),'Position');
                actrec.SetParam(SelBus(k),'Position',[blockPosition(1),blockPosition(2),blockPosition(1) + 5,blockPosition(2) + OutputNo*30]);
                actrec.SetParam(SelBus(k),'ShowName','off');
            end 
        end 
    end
    savehistory(handles,actrec);
end


%--------------------------------------------------------------------------
%   �� �� ����edit_cmdstr_Callback(hObject, eventdata, handles)
%   ������������������༭��ص�
%   �޸ļ�¼��
%--------------------------------------------------------------------------
function edit_cmdstr_Callback(hObject, eventdata, handles)
    %�ص��ݲ����κβ���
end 


%--------------------------------------------------------------------------
%   �� �� ����edit_cmdstr_CreateFcn(hObject, eventdata, handles)
%   ������������������༭�򴴽��ص�
%   �޸ļ�¼��
%             2022/05/17    xuhongjiang01    ����ʱ��ǿ���޸�ǰ���ڣ�������
%--------------------------------------------------------------------------
function edit_cmdstr_CreateFcn(hObject, eventdata, handles)

    %ispc�����ж��Ƿ�Ϊwindows�汾���������help
    % PCϵͳ�£�Ϊ�����������ɶ���ǿ��ǰ���뱳����ɫ���������UI����
    if ispc     
        set(hObject, 'BackgroundColor', 'white', 'ForegroundColor', 'black');
    end 
end 


%--------------------------------------------------------------------------------------------------------
%   �� �� ����edit_cmdstr_KeyPressFcn(hObject, eventdata, handles)
%   ������������������༭����̰��»ص�
%   �޸ļ�¼��
%             2022/06/02    xuhongjiang01    �޸�����listbox�󣬾�����л��޷�����edit_cmdstr����
%--------------------------------------------------------------------------------------------------------
function edit_cmdstr_KeyPressFcn(hObject, eventdata, handles)

    actrec = saRecorder;
    PromptOn = strcmp( get( handles.promptlistbox, 'Visible' ), 'on' );
    UserData = get( hObject, 'UserData' );

    if PromptOn
        if strcmp( eventdata.Key, 'return' )
            contents = get( handles.promptlistbox, 'String' );
            index = get( handles.promptlistbox, 'Value' );
            uicontrol( handles.edit_cmdstr );                           %2022/06/02  �л����
            set( handles.edit_cmdstr, 'String', contents{ index } );
            set( handles.promptlistbox, 'Visible', 'off' );
        elseif strcmp( eventdata.Key, 'escape' )
            set( handles.promptlistbox, 'Visible', 'off' );
            uicontrol( handles.edit_cmdstr );                           %2022/06/02  �л����
            set( hObject, 'String', '' );
        elseif strcmp( eventdata.Key, 'downarrow' )
            contents = get( handles.promptlistbox, 'String' );
            index = get( handles.promptlistbox, 'Value' );
            set( handles.promptlistbox, 'Value', min( numel( contents ), index + 1 ) );
        elseif strcmp( eventdata.Key, 'uparrow' )
            contents = get( handles.promptlistbox, 'String' );
            index = get( handles.promptlistbox, 'Value' );
            set( handles.promptlistbox, 'Value', max( 1, index - 1 ) );
        elseif numel( eventdata.Character ) == 1
            try 
                jEditbox = findjobj( hObject );
                partstr = char( jEditbox.getText );
            catch err
                switch err.identifier
                    case {'MATLAB:UndefinedFunction'}
                        partstr = get( handles.edit_cmdstr, 'String' );
                    otherwise
                        partstr = '';
                end
            end
            
            if isempty( partstr )
                set( handles.promptlistbox, 'Visible', 'off' );
            else 
                liststr = handles.Console.UIGetPromptList( partstr );
                if ~isempty( liststr ) && strcmp( liststr{ 1 }, partstr )
                    set( handles.promptlistbox, 'Visible', 'off' );
                else 
                    show_promptlist( handles.promptlistbox, liststr );
                end 
            end 
        end 
    else 
        if strcmp( eventdata.Key, 'return' )
            cmdstr_return_callback( hObject, handles );
        elseif strcmp( eventdata.Key, 'escape' )
            set( hObject, 'String', '' );
            uicontrol( hObject );
        elseif isequal( eventdata.Modifier, { 'alt' } )
            switch eventdata.Key
                case 'downarrow'
                    actrec.Merge( handles.Console.RunCommand( 'shorter' ) );
                    set( handles.edit_cmdstr, 'String', 'shorter' );
                case 'uparrow'
                    actrec.Merge( handles.Console.RunCommand( 'longer' ) );
                    set( handles.edit_cmdstr, 'String', 'longer' );
                case 'leftarrow'
                    actrec.Merge( handles.Console.RunCommand( 'narrower' ) );
                    set( handles.edit_cmdstr, 'String', 'narrower' );
                case 'rightarrow'
                    actrec.Merge( handles.Console.RunCommand( 'wider' ) );
                    set( handles.edit_cmdstr, 'String', 'wider' );
                otherwise 
            end 
            savehistory( handles, actrec );
        elseif isequal( eventdata.Modifier, { 'control' } )
            actrec.Merge( handles.Console.RunCommand( 'line' ) );
        elseif isequal( eventdata.Key, 'f1' )
            try 
                jEditbox = findjobj( hObject );
                partstr = char( jEditbox.getText );
                liststr = handles.Console.UIGetPromptList( partstr );
                show_promptlist( handles.promptlistbox, liststr );
            catch
                %�ݲ�������
            end 
        elseif ismember( eventdata.Key, { 'downarrow', 'pagedown', 'uparrow', 'pageup' } )

            if ~isempty( UserData ) && isfield( UserData, 'History' )
                itemcnt = numel( UserData.History );
            else 
                return ;
            end 
            switch eventdata.Key
                case { 'downarrow', 'pagedown' }
                    UserData.Pointer = max( UserData.Pointer - 1, 1 );
                    set( hObject, 'String', UserData.History{ UserData.Pointer } );
                case { 'uparrow', 'pageup' }
                    UserData.Pointer = min( UserData.Pointer + 1, itemcnt );
                    set( hObject, 'String', UserData.History{ UserData.Pointer } );
            end 
            set( hObject, 'UserData', UserData );
        elseif numel( eventdata.Character ) == 1 && strcmp( get( handles.menu_showprompt, 'Checked' ), 'on' )
            try 
                jEditbox = findjobj( hObject );
                partstr = char( jEditbox.getText );
            catch err
                switch err.identifier
                    case {'MATLAB:UndefinedFunction'}
                        partstr = get( handles.edit_cmdstr, 'String' );
                    otherwise
                        partstr = '';
                end
            end 
            if isempty( partstr )
                set( handles.promptlistbox, 'Visible', 'off' );
            else 
                liststr = handles.Console.UIGetPromptList( partstr );
                if ~isempty( liststr ) && strcmp( liststr{ 1 }, partstr )
                else 
                    show_promptlist( handles.promptlistbox, liststr );
                end 
            end 
        else 
        end 
    end 
end 

function cmdstr_return_callback( hObject, handles )
    actrec = saRecorder;
    try 
        jEditbox = findjobj( hObject );
        cmdstr = char( jEditbox.getText );
    catch err
        switch err.identifier
            case {'MATLAB:UndefinedFunction'}
                cmdstr = get( handles.edit_cmdstr, 'String' );
            otherwise
                cmdstr = '';
        end
    end 
    prompton = strcmp( get( handles.promptlistbox, 'Visible' ), 'on' );
    if isempty( cmdstr ) || prompton
        return ;
    end 

    actrec = handles.Console.RunCommand( cmdstr );

    savehistory( handles, actrec );

    ud = get( hObject, 'UserData' );
    if isempty( ud ) || ~isfield( ud, 'History' )
        ud.History = {  };
        ud.Pointer = 0;
    elseif numel( ud.History ) >= 400
        ud.History( end  ) = [  ];
    else 
    end 
    if ~isempty( ud.History ) && strcmp( cmdstr, ud.History{ 1 } )

    else 
        ud.History = [ cmdstr;ud.History ];
        ud.Pointer = 1;
        set( hObject, 'UserData', ud );
    end 
end


%--------------------------------------------------------------------------
%   �� �� ����menu_editcmd_Callback(hObject, eventdata, handles)
%   ����������editcmd�Ҽ��˵��ص�
%   �޸ļ�¼��
%--------------------------------------------------------------------------
function menu_editcmd_Callback(hObject, eventdata, handles)

end

%--------------------------------------------------------------------------
%   �� �� ����promptlistbox_Callback(hObject, eventdata, handles)
%   �����������б���ص�
%   �޸ļ�¼��
%--------------------------------------------------------------------------
function promptlistbox_Callback( hObject, eventdata, handles )

end 


%--------------------------------------------------------------------------
%   �� �� ����promptlistbox_CreateFcn(hObject, eventdata, handles)
%   �����������б��򴴽��ص�
%   �޸ļ�¼��
%             2022/05/17    xuhongjiang01    ����ʱ��ǿ���޸�ǰ���ڣ�������
%--------------------------------------------------------------------------
function promptlistbox_CreateFcn( hObject, eventdata, handles )

    if ispc && isequal( get( hObject, 'BackgroundColor' ), get( 0, 'defaultUicontrolBackgroundColor' ) )
        set( hObject, 'BackgroundColor', 'white' );
    end 
end 


%--------------------------------------------------------------------------------------------------------
%   �� �� ����promptlistbox_KeyPressFcn(hObject, eventdata, handles)
%   �����������б�����̰��»ص�
%   �޸ļ�¼��
%--------------------------------------------------------------------------------------------------------
function promptlistbox_KeyPressFcn( hObject, eventdata, handles )

    if strcmp( eventdata.Key, 'return' )
        contents = get( hObject, 'String' );
        index = get( hObject, 'Value' );
        set( handles.edit_cmdstr, 'String', contents{ index } );
        set( hObject, 'Visible', 'off', 'Value', 1, 'String', { '#None#' } );
    elseif strcmp( eventdata.Key, 'escape' )
        set( hObject, 'Visible', 'off', 'Value', 1, 'String', { '#None#' } );
        uicontrol( handles.edit_cmdstr );
    end 
end 


%--------------------------------------------------------------------------
%   �� �� ����menu_showprompt_Callback(hObject, eventdata, handles)
%   ����������editcmd�Ҽ��˵��ص�
%   �޸ļ�¼��
%--------------------------------------------------------------------------
function menu_showprompt_Callback( hObject, eventdata, handles )

    if strcmp( get( hObject, 'Checked' ), 'on' )
        set( hObject, 'Checked', 'off' );
    else 
        set( hObject, 'Checked', 'on' );
    end
    
end 


%--------------------------------------------------------------------------
%   �� �� ����ExpandBtn_Callback(hObject, eventdata, handles)
%   ���������������չ��ť�ص�
%   �޸ļ�¼��
%--------------------------------------------------------------------------
function ExpandBtn_Callback(hObject, eventdata, handles)
    PanelPos = get( handles.uipanel3, 'Position' );
    BtnPos = get( hObject, 'Position' );
    
    % ���ݷ����ж���չ���ջأ����µ������λ��
    if strcmpi( get( hObject, 'String' ), '>' )             
        FigPos = get( handles.HYAssist, 'Position' );
        FigPos( 3 ) = PanelPos( 1 ) + PanelPos( 3 ) + 5;
        set( handles.HYAssist, 'Position', FigPos );
        set( hObject, 'String', '<' );
    elseif strcmpi( get( hObject, 'String' ), '<' )
        FigPos = get( handles.HYAssist, 'Position' );
        FigPos( 3 ) = BtnPos( 1 ) + BtnPos( 3 ) + 5;
        set( handles.HYAssist, 'Position', FigPos );
        set( hObject, 'String', '>' );
    end 
end 


%-------------------------------------------------------------------------------
%   �� �� ����popmenu_blk_Callback(hObject, eventdata, handles)
%   ����������blk�����б������ص�
%   �޸ļ�¼��
%             2022/05/17    xuhongjiang01    ������������ʱ������༭���ַ�����
%-------------------------------------------------------------------------------
function popmenu_blk_Callback(hObject, eventdata, handles)
    %ֻҪ��ѡ������������
    uicontrol(handles.edit_paraval);
    set(handles.edit_paraval, 'String', '');
    uicontrol(hObject);
    
    alldlgparas = {  };
    BlkTypeStr = get( hObject, 'String' );
    propstr = get( handles.popmenu_prop, 'String' );
    if ~isempty( propstr )
        OldProp = propstr{ get( handles.popmenu_prop, 'Value' ) };
    else 
        OldProp = '';
    end 
    blks = find_system( gcs, 'SearchDepth', 1, 'LookUnderMasks', 'on', 'FollowLinks', 'on', 'Selected', 'on' );
    if numel( blks ) == 0
        return ;
    end 
    if strcmp( blks{ 1 }, gcs )
        blks = blks( 2:numel( blks ) );
    end 
    if isempty( BlkTypeStr{ get( hObject, 'Value' ) } )
        return ;
    elseif strcmp( BlkTypeStr{ get( hObject, 'Value' ) }, 'ALL' )
        for i = 1:numel( blks )
            try 
                dlgparas = [ fieldnames( get_param( blks{ i }, 'DialogParameters' ) );handles.ExtraDlgParas ];
                alldlgparas = [ alldlgparas;dlgparas ];
            catch err
                %��ʱ������
            end 
        end 
    else 
        for i = 1:numel( blks )
            if strcmpi( get_param( blks{ i }, 'BlockType' ), BlkTypeStr{ get( hObject, 'Value' ) } )
                try 
                alldlgparas = [ fieldnames( get_param( blks{ i }, 'DialogParameters' ) );handles.ExtraDlgParas ];
                catch err
                            %��ʱ������
                end 
                break ;
            end 
        end 
    end
    
    alldlgparas = unique( alldlgparas );
    if isempty( alldlgparas )
        alldlgparas = { '---' };
        set( handles.popmenu_prop, 'String', alldlgparas, 'Value', 1 );
    elseif ~isempty( OldProp ) && ~isempty( strmatch( OldProp, alldlgparas ) )
        set( handles.popmenu_prop, 'String', alldlgparas );
        set( handles.popmenu_prop, 'Value', strmatch( OldProp, alldlgparas ) );
    else 
        set( handles.popmenu_prop, 'String', alldlgparas, 'Value', 1 );
    end 


    paravals = {  };
    if strcmp( BlkTypeStr{ get( hObject, 'Value' ) }, 'ALL' )
        filtblks = blks;
    else 
        filtblks = find_system( blks, 'BlockType', BlkTypeStr{ get( hObject, 'Value' ) } );
    end 
    for i = 1:numel( filtblks )
        try 
            blkval = get_param( filtblks{ i }, alldlgparas{ get( handles.popmenu_prop, 'Value' ) } );
            paravals = [ paravals;blkval ];
        catch err
                                %��ʱ������
        end 
    end 
    paravals = unique( paravals );
    if isempty( paravals )
        paravals = { '---' };
    end 
    set( handles.popmenu_val, 'String', paravals, 'Value', 1 );
end 


%--------------------------------------------------------------------------
%   �� �� ����popmenu_blk_CreateFcn(hObject, eventdata, handles)
%   ����������blk�����б������ص�
%   �޸ļ�¼��
%             2022/05/17    xuhongjiang01    ����ʱ��ǿ���޸�ǰ���ڣ�������
%--------------------------------------------------------------------------
function popmenu_blk_CreateFcn(hObject, eventdata, handles)
    if ispc
        set(hObject, 'BackgroundColor', 'white', 'ForegroundColor', 'black');
    end
end 


%-------------------------------------------------------------------------------
%   �� �� ����popmenu_prop_Callback(hObject, eventdata, handles)
%   ����������prop�����б������ص�
%   �޸ļ�¼��
%             2022/05/17    xuhongjiang01    ������������ʱ������༭���ַ�����
%-------------------------------------------------------------------------------
function popmenu_prop_Callback( hObject, eventdata, handles )
    %ֻҪ��ѡ������������
    uicontrol(handles.edit_paraval);
    set(handles.edit_paraval, 'String', '');
    uicontrol(hObject);
    
    ParVals = { };
    PropStr = get(hObject, 'String');
    BlkTypeStr = get(handles.popmenu_blk, 'String');
    Blks = find_system(gcs, 'SearchDepth', 1, 'LookUnderMasks', 'on', 'FollowLinks', 'on', 'Selected', 'on');
    
    if numel(Blks) == 0
        return;
    end
    
    if strcmp(Blks{ 1 }, gcs)
        Blks = Blks(2:numel(Blks));
    end
    
    if isempty(PropStr)
        return;
    elseif strcmpi(PropStr{ get( hObject, 'Value' ) }, '---')
        return;
    else
        %����ģ�飬ѡ��ALLʱ�������ˣ����򣬸���ģ�����͹���
        if strcmp(BlkTypeStr{get(handles.popmenu_blk, 'Value')}, 'ALL')
            FiltBlks = Blks;
        else 
            FiltBlks = find_system(Blks, 'BlockType', BlkTypeStr{get(handles.popmenu_blk, 'Value')});
        end

        for i = 1:numel(FiltBlks)
            try 
                BlkVal = get_param(FiltBlks{i}, PropStr{get(hObject, 'Value')});
                ParVals = [ParVals;BlkVal];
            catch err
                %��ʱ������
                switch err.identifier
                end
            end 
        end 
        ParVals = unique(ParVals);
        if isempty(ParVals)
            ParVals = { '---' };
        end 
        set(handles.popmenu_val, 'String', ParVals, 'Value', 1);
    end 
end 


%--------------------------------------------------------------------------
%   �� �� ����popmenu_prop_CreateFcn(hObject, eventdata, handles)
%   ����������prop�����б������ص�
%   �޸ļ�¼��
%             2022/05/17    xuhongjiang01    ����ʱ��ǿ���޸�ǰ���ڣ�������
%--------------------------------------------------------------------------
function popmenu_prop_CreateFcn(hObject, eventdata, handles)
    if ispc
        set(hObject, 'BackgroundColor', 'white', 'ForegroundColor', 'black');
    end
end 


%-----------------------------------------------------------------------------
%   �� �� ����popmenu_val_Callback(hObject, eventdata, handles)
%   ����������val�����б������ص�
%   �޸ļ�¼��
%             2022/05/17    xuhongjiang01    ������������ʱ������༭���ַ�����
%-----------------------------------------------------------------------------
function popmenu_val_Callback( hObject, eventdata, handles )
    %ֻҪ��ѡ������������
    uicontrol(handles.edit_paraval);
    set(handles.edit_paraval, 'String', '');
    uicontrol(hObject);
end 


%--------------------------------------------------------------------------
%   �� �� ����popmenu_val_CreateFcn(hObject, eventdata, handles)
%   ����������val�����б������ص�
%   �޸ļ�¼��
%             2022/05/17    xuhongjiang01    ����ʱ��ǿ���޸�ǰ���ڣ�������
%--------------------------------------------------------------------------
function popmenu_val_CreateFcn(hObject, eventdata, handles)
    if ispc
        set(hObject, 'BackgroundColor', 'white', 'ForegroundColor', 'black');
    end
end 


%--------------------------------------------------------------------------
%   �� �� ����edit_paraval_Callback(hObject, eventdata, handles)
%   ����������paraval�༭��ص�
%   �޸ļ�¼��
%--------------------------------------------------------------------------
function edit_paraval_Callback( hObject, eventdata, handles )

end 


%--------------------------------------------------------------------------
%   �� �� ����edit_paraval_CreateFcn(hObject, eventdata, handles)
%   ����������paraval�༭�򴴽��ص�
%   �޸ļ�¼��
%             2022/05/17    xuhongjiang01    ����ʱ��ǿ���޸�ǰ���ڣ�������
%--------------------------------------------------------------------------
function edit_paraval_CreateFcn( hObject, eventdata, handles )
    if ispc
        set(hObject, 'BackgroundColor', 'white', 'ForegroundColor', 'black');
    end
end


%----------------------------------------------------------------------------
%   �� �� ����edit_paraval_KeyPressFcn(hObject, eventdata, handles)
%   ������������չ��������༭����̰��»ص�
%   �޸ļ�¼��
%             2022/05/17    xuhongjiang01    �����ص����趨Esc������ַ�������
%----------------------------------------------------------------------------
function edit_paraval_KeyPressFcn(hObject, eventdata, handles)
    if strcmp(eventdata.Key, 'escape')
        set(hObject, 'String', '');
        uicontrol(hObject);
    end
end


%--------------------------------------------------------------------------
%   �� �� ����show_promptlist(hObject, liststr)
%   ���������������б���ʾ����
%   �޸ļ�¼��
%--------------------------------------------------------------------------
function show_promptlist(hObject, liststr)
    if ~isempty(liststr)
        Pos = get( hObject, 'Position' );
        hfig = get( hObject, 'Parent' );
        FigPos = get( hfig, 'Position' );
        Pos( 4 ) = min((numel(liststr) + 1) * 10, FigPos(4) - 30);
        OldVal = get(hObject, 'Value');
        set(hObject, 'Value', min(OldVal, numel(liststr)), 'String', liststr, 'Position', Pos, 'Visible', 'on');
    else 
        set(hObject, 'Visible', 'off', 'Value', 1, 'String', { '#None#' });
    end 
end 


%--------------------------------------------------------------------------
%   �� �� ����btnSearch_Callback(hObject, eventdata, handles)
%   ����������Search��ť�����ص�
%   �޸ļ�¼��
%--------------------------------------------------------------------------
function btnSearch_Callback( hObject, eventdata, handles )

    Blks = find_system(gcs, 'SearchDepth', 1, 'LookUnderMasks', 'on', 'FollowLinks', 'on', 'Selected', 'on');
    if isempty( Blks )
        return;
    end
    
    if strcmp(Blks{ 1 }, gcs)
        Blks = Blks(2:numel(Blks));
    end 

    BlkTypes = unique(get_param(Blks, 'BlockType'));
    BlkTypes = [{ 'ALL' };BlkTypes];
    set(handles.popmenu_blk, 'String', BlkTypes, 'Value', 1);

    Propstr = get(handles.popmenu_prop, 'String');
    if ~isempty( Propstr )
        OldProp = Propstr{get( handles.popmenu_prop, 'Value')};
    else 
        OldProp = '';
    end
    
    AllDlgParas = {  };
    for i = 1:numel(Blks)
        try 
            DlgParas = [fieldnames(get_param(Blks{i}, 'DialogParameters'));handles.ExtraDlgParas];
            AllDlgParas = [AllDlgParas;DlgParas];
        catch err
            %��ʱ������
            switch err.identifier
            end
        end 
    end
    
    AllDlgParas = unique(AllDlgParas);
    if isempty( AllDlgParas )
        AllDlgParas = { '---' };
        set(handles.popmenu_prop, 'String', AllDlgParas, 'Value', 1);
    elseif ~isempty( OldProp ) && ~isempty( strmatch( OldProp, AllDlgParas ) )
        set(handles.popmenu_prop, 'String', AllDlgParas, 'Value', strmatch(OldProp, AllDlgParas, 'exact'));
    else 
        set(handles.popmenu_prop, 'String', AllDlgParas, 'Value', 1);
    end 

    set(handles.popmenu_prop, 'String', AllDlgParas);

    ParaVals = { };
    for i = 1:numel(Blks)
        try 
            blkval = get_param(Blks{i}, AllDlgParas{get(handles.popmenu_prop, 'Value')});
            ParaVals = [ParaVals;blkval];
        catch err
            %��ʱ������
            switch err.identifier
            end
        end 
    end
    
    ParaVals = unique(ParaVals);
    if isempty(ParaVals)
        ParaVals = { '---' };
    end 
    set(handles.popmenu_val, 'String', ParaVals, 'Value', 1);
end 


%--------------------------------------------------------------------------
%   �� �� ����btnApplyPropChg_Callback(hObject, eventdata, handles)
%   ����������Apply��ť�����ص�
%   �޸ļ�¼��
%--------------------------------------------------------------------------
function btnApplyPropChg_Callback( hObject, eventdata, handles )

    actrec = saRecorder;
    Blks = find_system(gcs, 'SearchDepth', 1, 'LookUnderMasks', 'on', 'FollowLinks', 'on', 'Selected', 'on');
    if isempty(Blks)
        return;
    end
    
    if strcmp(Blks{1}, gcs)
        Blks = Blks(2:numel(Blks));
    end
    
    BlkTypeStr = get(handles.popmenu_blk, 'String');
    PropStr = get(handles.popmenu_prop, 'String');
    ValStr = get(handles.popmenu_val, 'String');
    try 
        if strcmp(BlkTypeStr{get(handles.popmenu_blk, 'Value' )}, 'ALL')
            FiltBlks = Blks;
        else 
            FiltBlks = find_system(Blks, 'BlockType', BlkTypeStr{get(handles.popmenu_blk, 'Value')});
        end
        
        Prop = PropStr{ get(handles.popmenu_prop, 'Value') };

        if ~isempty(get(handles.edit_paraval, 'String'))    %����ʹ�ñ༭���������ַ���
            Val = get(handles.edit_paraval, 'String');
        else 
            Val = ValStr{ get(handles.popmenu_val, 'Value') };
        end 
    catch 
        return;
    end 

    if ~isempty(regexp(Val, '\[.*\]'))
        cmdpsr = saCmdParser( Val, '' );
        [ opt, bclean ] = cmdpsr.ParseMultiValues;
    else 
        opt = Val;
    end 

    for i = 1:numel( FiltBlks )
        if iscellstr( opt )
            PropVal = opt{ min( i, end  ) };
        else 
            PropVal = opt;
        end 
        objhdl = get_param( FiltBlks{ i }, 'Handle' );
        try 
            actrec.SetParamHighlight( objhdl, Prop, PropVal );
        catch 
            continue;
        end 
    end 
    savehistory( handles, actrec );
end 




function btn_brklnk_Callback( hObject, eventdata, handles )


end 


function mi_dictrename_sf_Callback( hObject, eventdata, handles )

    if strcmp( get( hObject, 'Checked' ), 'on' )
        set( hObject, 'Checked', 'off' );
        set( handles.btn_refine_name, 'String', 'A-A''' );
    else 
        set( hObject, 'Checked', 'on' );
        set( handles.btn_refine_name, 'String', 'S-S''' );
    end
    
end 


function menu_dictrename_Callback( hObject, eventdata, handles )

end 


function mi_checkstatus_Callback( hObject, eventdata, handles )

    if strcmp( get( hObject, 'Checked' ), 'off' )
        set( hObject, 'Checked', 'on' );
    else 
        set( hObject, 'Checked', 'off' );
    end 
end
