function varargout = saDlg_AddNewBlock( varargin )

    gui_Singleton = 1;
    gui_State = struct( 'gui_Name', mfilename,  ...
    'gui_Singleton', gui_Singleton,  ...
    'gui_OpeningFcn', @saDlg_AddNewBlock_OpeningFcn,  ...
    'gui_OutputFcn', @saDlg_AddNewBlock_OutputFcn,  ...
    'gui_LayoutFcn', [  ],  ...
    'gui_Callback', [  ] );
    if nargin && ischar( varargin{ 1 } )
        gui_State.gui_Callback = str2func( varargin{ 1 } );
    end 

    if nargout
        [ varargout{ 1:nargout } ] = gui_mainfcn( gui_State, varargin{ : } );
    else 
        gui_mainfcn( gui_State, varargin{ : } );
    end 
end



function saDlg_AddNewBlock_OpeningFcn( hObject, eventdata, handles, varargin )

    dd = dir( '.\+Routines' );
    routinenames = regexprep( { dd( ~[ dd.isdir ] ).name }', '\..*', '' );
    set( handles.pop_routine, 'String', routinenames, 'Value', strmatch( 'majorprop_value', routinenames, 'exact' ) );
    if nargin > 3
    initialize_uicontrols( handles, varargin{ 1 } );
    end 
    handles.Cancel = true;

    guidata( hObject, handles );
    uiwait( handles.sadlg_addnewblock );
end

function initialize_uicontrols( handles, info )
    if isobject( info )
        %�����κ�����
    elseif isstruct( info )
        set( handles.edit_patternstr, 'String', safe_get( info, 'RoutinePattern' ) );
        set( handles.edit_priority, 'String', num2str( safe_get( info, 'RoutinePriority' ) ) );
    elseif ischar( info ) || isnumeric( info )
        newbt = saBlock( info );
        set( handles.blockpath, 'String', newbt.GetSourcePath );
    end 
end

function val = safe_get( h, prop )
    val = '';
    if isobject( h )
        if isprop( h, prop )
            val = h.( prop );
        end 
    else 
        if isfield( h, prop )
            val = h.( prop );
        end 
    end 
end


function varargout = saDlg_AddNewBlock_OutputFcn( hObject, eventdata, handles )

    if ~isempty( handles )
    if ~handles.Cancel
    info = collect_info( handles );

    varargout{ 1 } = info;
    else 
    varargout{ 1 } = [  ];
    end 
    close( handles.sadlg_addnewblock );
    else 
    varargout{ 1 } = [  ];
    end
end

function info = collect_info( handles )
    info.RoutinePattern = get( handles.edit_patternstr, 'String' );
    info.RoutinePriority = str2double( get( handles.edit_priority, 'String' ) );
    contents = cellstr( get( handles.pop_routine, 'String' ) );
    info.RoutineMethod = contents{ get( handles.pop_routine, 'Value' ) };
    rttbldata = get( handles.tbl_routinepara, 'Data' );
    for i = 1:size( rttbldata, 1 )
        if ~isempty( rttbldata{ i, 1 } ) && ischar( rttbldata{ i, 1 } )
            info.RoutinePara.( rttbldata{ i, 1 } ) = rttbldata{ i, 2 };
        end 
    end 
    majprop = get( handles.edit_majorprop, 'String' );
    if ~isempty( majprop )
        info.MajorProperty = get( handles.edit_majorprop, 'String' );
    end 
    info.BlockPreferOption.ShowName = num2onoff( get( handles.chk_showname, 'Value' ) );
    info.BlockPreferOption.Selected = num2onoff( get( handles.chk_select, 'Value' ) );
end

function out = num2onoff( in )
    if ~ischar( in )
        if in
            out = 'on';
        else 
            out = 'off';
        end 
    else 
        out = in;
    end
end


function edit_patternstr_Callback( hObject, eventdata, handles )

end


function edit_patternstr_CreateFcn( hObject, eventdata, handles )

    if ispc && isequal( get( hObject, 'BackgroundColor' ), get( 0, 'defaultUicontrolBackgroundColor' ) )
        set( hObject, 'BackgroundColor', 'white' );
    end 
end


function edit_priority_Callback( hObject, eventdata, handles )

end

function edit_priority_CreateFcn( hObject, eventdata, handles )

    if ispc && isequal( get( hObject, 'BackgroundColor' ), get( 0, 'defaultUicontrolBackgroundColor' ) )
        set( hObject, 'BackgroundColor', 'white' );
    end
end


function pop_routine_Callback( hObject, eventdata, handles )

end


function pop_routine_CreateFcn( hObject, eventdata, handles )

    if ispc && isequal( get( hObject, 'BackgroundColor' ), get( 0, 'defaultUicontrolBackgroundColor' ) )
        set( hObject, 'BackgroundColor', 'white' );
    end 
end


function chk_showname_Callback( hObject, eventdata, handles )

end


function chk_select_Callback( hObject, eventdata, handles )

end


function btn_ok_Callback( hObject, eventdata, handles )

    uiresume( handles.sadlg_addnewblock );
    handles.Cancel = false;
    guidata( hObject, handles );
end

function btn_cancel_Callback( hObject, eventdata, handles )

    uiresume( handles.sadlg_addnewblock );
    handles.Cancel = true;
    guidata( hObject, handles );
end


function btn_tom_Callback( hObject, eventdata, handles )

    newbt = saBlock( gcbh );
    info = collect_info( handles );
    if ~isempty( info ) && ~isempty( info.RoutinePattern )
        flds = fieldnames( info );
        for i = 1:numel( flds )
            newbt.( flds{ i } ) = info.( flds{ i } );
        end 
    end 
    newbt.CreateMFile;
end


function edit_majorprop_Callback( hObject, eventdata, handles )

end

function edit_majorprop_CreateFcn( hObject, eventdata, handles )
    if ispc && isequal( get( hObject, 'BackgroundColor' ), get( 0, 'defaultUicontrolBackgroundColor' ) )
        set( hObject, 'BackgroundColor', 'white' );
    end
end