classdef saObject < dynamicprops

    properties 
        Console
        MapKey
        ObjectType
    end 

    methods 
        function obj = saObject( varargin )
            obj.ObjectType = varargin{ 1 };
        end 

        function tf = isa( obj, type )
            tf = strcmpi( obj.ObjectType, type );
        end 
    end 
end
