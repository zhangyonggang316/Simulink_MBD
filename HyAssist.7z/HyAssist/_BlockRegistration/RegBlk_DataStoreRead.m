%-------------------------------------------------------------------------------------------
%   �� �� ����RegBlk_DataStoreRead.m
%   �ļ�������DataStoreReadģ��ע��
%   ��    ����V1.1.0
%   �޸ļ�¼��
%            2022/06/09     xuhongjiang01    �Զ���С��������AutoSizeMethod��-2��Ϊ-4
%-------------------------------------------------------------------------------------------
function sabt = RegBlk_DataStoreRead

    sabt = saBlock( 'DataStoreRead' );

    sabt.RoutinePattern = '';

    sabt.BroBlockType = { 'DataStoreWrite', 'DataStoreMemory' };
    sabt.CreateBroBlockMethod =  - 1;
    sabt.ConnectPort = [ 0, 1 ];

    sabt.MajorProperty = 'DataStoreName';
    sabt.DictRenameMethod = 1;

    sabt.PropagateDownstreamStringMethod = 'DataStoreName';
    sabt.OutportStringMethod = 'DataStoreName';
    sabt.RefineMethod = @refine_method;


    sabt.BlockSize = [ 100, 30 ];
    sabt.LayoutSize.VerticalMargin = 30;
    sabt.LayoutSize.CharWidth = 6;

    sabt.AutoSizeMethod = -4;

    sabt.GetBroMethod = @saFindBroBlocks;
end 


function actrec = refine_method( blkhdl )
    actrec = saRecorder;
    name = get_param( blkhdl, 'DataStoreName' );
    actrec.SetParam( blkhdl, 'Name', [ name, '_DSR' ], 'ShowName', 'off' );
end