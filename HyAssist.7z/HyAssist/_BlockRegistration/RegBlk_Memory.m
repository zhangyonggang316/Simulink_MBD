function sabt = RegBlk_Memory

    sabt = saBlock( 'Memory' );
    sabt.RoutinePattern = '^memory|mem';
    sabt.RoutinePriority = 20;
    sabt.RoutineMethod = 'majorprop_value';
    sabt.BlockPreferOption.ShowName = 'off';
    sabt.BlockPreferOption.Selected = 'off';

end
