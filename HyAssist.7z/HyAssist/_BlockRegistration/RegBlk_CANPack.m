%-------------------------------------------------------------------------------------------
%   �� �� ����RegBlk_CANPack.m
%   �ļ�������CANPackģ��ע��
%   ��    ����V1.0.0
%   �޸ļ�¼��
%-------------------------------------------------------------------------------------------
function sabt = RegBlk_CANPack
    sabt = saBlock( 'canmsglib/CAN Pack' );

    sabt.InportStringMethod = @inport_string_canpack;

end 


function thestr = inport_string_canpack( pthdl )
    ptnum = get_param( pthdl, 'PortNumber' );
    parblk = get_param( pthdl, 'Parent' );
    mskwsvars = get_param( parblk, 'MaskWSVariables' );
    portvar = mskwsvars( strcmp( { mskwsvars.Name }, 'port' ) ).Value;

    thestr = portvar( ptnum ).label;
end