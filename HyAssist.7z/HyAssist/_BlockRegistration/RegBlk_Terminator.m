%-------------------------------------------------------------------------------------------
%   �� �� ����RegBlk_Terminator.m
%   �ļ�������Terminatorģ��ע��
%   ��    ����V1.1.0
%   �޸ļ�¼��
%            2022/06/09     xuhongjiang01    �޸�BlockSizeΪ20x20
%-------------------------------------------------------------------------------------------
function sabt = RegBlk_Terminator

    sabt = saBlock( 'Terminator' );
    sabt.RoutineMethod = 'num_only';
    sabt.RoutinePattern = '^(terminator|term)';

    sabt.PropagateUpstreamStringMethod = 'Name';

    sabt.ConnectPort = [ 1, 0 ];
    sabt.BlockSize = [ 20, 20 ];
    sabt.AutoSizeMethod = -6;
end