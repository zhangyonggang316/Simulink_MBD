function sabt = RegBlk_Goto
    sabt = saBlock( 'Goto' );
    sabt.RoutineMethod = 'majorprop_str_num';
    sabt.RoutinePattern = '^goto';


    sabt.BroBlockType = { 'From', 'GotoTagVisibility' };
    sabt.CreateBroBlockMethod =  - 1;
    sabt.ConnectPort = [ 1, 0 ];

    sabt.MajorProperty = 'GotoTag';
    sabt.DictRenameMethod = 1;

    sabt.PropagateDownstreamStringMethod =  - 1;
    sabt.PropagateUpstreamStringMethod = 'GotoTag';
    sabt.InportStringMethod = 'GotoTag';
    sabt.OutportStringMethod =  - 1;

%     sabt.AnnotationMethod = 'Scope: %<TagVisibility>';
    sabt.RefineMethod = @refine_method;
    sabt.ColorMethod = {  - 1, false };

    sabt.BlockSize = [ 100, 14 ];
    sabt.LayoutSize.VerticalMargin = 14;
    sabt.LayoutSize.CharWidth = 6;

    parobj = RegBlk_DataStoreWrite;
    sabt.Inherit( parobj, 'AutoSizeMethod' );

    sabt.GetBroMethod = @saFindBroBlocks;
end 

function actrec = refine_method( BlkHndl )
    actrec = saRecorder;
    tag = get_param( BlkHndl, 'GotoTag' );
    newval = [ tag, '_', get_param( BlkHndl, 'BlockType' ) ];
    actrec.SetParam( BlkHndl, 'Name', newval,'BackgroundColor','red','ShowName','off'  );
end