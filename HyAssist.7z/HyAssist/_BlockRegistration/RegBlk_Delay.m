function sabt = RegBlk_Delay

    sabt = saBlock( 'Delay' );
    sabt.RoutineMethod = 'majorprop_value';
    sabt.RoutinePattern = '^(dly|delay)';
    sabt.MajorProperty = 'DelayLength';
    sabt.AnnotationMethod = 'Delay: %<DelayLength>';
    sabt.BlockSize = [ 35, 34 ];
    sabt.DataTypeMethod =  - 1;
    sabt.DefaultParameters = { 'SampleTime', '-1', 'AttributesFormatString', 'Delay: %<DelayLength>' };

end
