%-------------------------------------------------------------------------------------------
%   �� �� ����RegBlk_DataStoreMemory.m
%   �ļ�������DataStoreMemoryģ��ע��
%   ��    ����V1.1.0
%   �޸ļ�¼��
%            2022/06/09     xuhongjiang01    ����ע�ͷ�����ע��
%-------------------------------------------------------------------------------------------
function sabt = RegBlk_DataStoreMemory

    sabt = saBlock( 'DataStoreMemory' );

    sabt.RoutinePattern = '';

    sabt.BroBlockType = { 'DataStoreWrite', 'DataStoreRead' };
    sabt.CreateBroBlockMethod =  - 1;
    sabt.ConnectPort = [ 0, 0 ];

    sabt.MajorProperty = 'DataStoreName';
    sabt.DictRenameMethod = 1;

    sabt.PropagateDownstreamStringMethod = 'DataStoreName';
    sabt.OutportStringMethod = 'DataStoreName';
%     sabt.AnnotationMethod = 'DT: %<OutDataTypeStr>';
    sabt.RefineMethod = @refine_method;

    sabt.BlockSize = [ 100, 30 ];
    sabt.LayoutSize.VerticalMargin = 30;
    sabt.LayoutSize.CharWidth = 6;

    parobj = RegBlk_Constant;
    sabt.Inherit( parobj, 'AutoSizeMethod' );

    sabt.GetBroMethod = @saFindBroBlocks;
end 

function actrec = refine_method( blkhdl )
    actrec = saRecorder;
    name = get_param( blkhdl, 'DataStoreName' );
    actrec.SetParam( blkhdl, 'Name', [ name, '_DSM' ], 'ShowName', 'off' );
end 
