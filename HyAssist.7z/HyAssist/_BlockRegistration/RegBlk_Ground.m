function sabt = RegBlk_Ground
    
    sabt = saBlock( 'Ground' );
    sabt.RoutineMethod = 'num_only';
    sabt.RoutinePattern = '^(gnd|ground)';
    sabt.PropagateDownstreamStringMethod = 'Name';
    sabt.BlockSize = [ 20, 20 ];
    sabt.ConnectPort = [ 0, 1 ];
    
end