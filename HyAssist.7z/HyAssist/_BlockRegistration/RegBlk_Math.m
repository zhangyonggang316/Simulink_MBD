function sabt = RegBlk_Math
    sabt = saBlock( 'Math' );

    sabt.RoutineMethod = @routine_math;
    sabt.RoutinePattern = '^(exp|log10|log|square|reciprocal|pow|rem|mod)';
    sabt.RoutinePriority = 51;

    sabt.BlockSize = [ 25, 25 ];

    sabt.MajorProperty = 'Operator';
    sabt.RollPropertyMethod =  - 1;
end 

function [ actrec, success ] = routine_math( cmdstr, console )
    btobj = console.MapTo( 'Math' );

    cmdpsr = saCmdParser( cmdstr, btobj.RoutinePattern );
    [ actrec, success ] = Routines.num_only( btobj, cmdpsr.OptionStr, '', 'Operator', cmdpsr.PatternStr );
end