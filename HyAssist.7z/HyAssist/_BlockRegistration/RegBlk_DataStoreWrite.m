%-------------------------------------------------------------------------------------------
%   �� �� ����RegBlk_DataStoreWrite.m
%   �ļ�������DataStoreWriteģ��ע��
%   ��    ����V1.1.1
%   �޸ļ�¼��
%            2022/06/09     xuhongjiang01    �Զ���С��������AutoSizeMethod��-3��Ϊ-5
%            2022/07/01     xuhongjiang01    ����RefineMethod
%-------------------------------------------------------------------------------------------
function sabt = RegBlk_DataStoreWrite

    sabt = saBlock( 'DataStoreWrite' );

    sabt.RoutinePattern = '';

    sabt.BroBlockType = { 'DataStoreRead', 'DataStoreMemory' };
    sabt.CreateBroBlockMethod =  - 1;
    sabt.ConnectPort = [ 1, 0 ];

    sabt.MajorProperty = 'DataStoreName';
    sabt.DictRenameMethod = 1;

    sabt.PropagateUpstreamStringMethod = 'DataStoreName';
    sabt.OutportStringMethod = 'DataStoreName';
    sabt.RefineMethod = @Refine_DataStoreWrite;

    sabt.BlockSize = [ 100, 30 ];
    sabt.LayoutSize.VerticalMargin = 30;
    sabt.LayoutSize.CharWidth = 6;

    sabt.AutoSizeMethod = -5;

    sabt.GetBroMethod = @saFindBroBlocks;
end


function actrec = Refine_DataStoreWrite( BlkHndl )
    actrec = saRecorder;
    name = get_param( BlkHndl, 'DataStoreName' );
    actrec.SetParam( BlkHndl, 'Name', [ name, '_DSW' ], 'ShowName', 'off' );
end