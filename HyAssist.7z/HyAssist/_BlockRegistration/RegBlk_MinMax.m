%-------------------------------------------------------------------------------------------
%   �� �� ����RegBlk_MinMax.m
%   �ļ�������MinMaxģ��ע��
%   ��    ����V1.0.1
%   �޸ļ�¼��
%            2022/07/31    xuhongjiang01    1���������Թ������壬��������߼�
%-------------------------------------------------------------------------------------------
function sabt = RegBlk_MinMax
    sabt = saBlock( 'MinMax' );
    sabt.RoutinePattern = '^min|max';
    sabt.RoutineMethod = @routine_minmax;
    sabt.RoutinePara.InportProperty = 'Inputs';

    sabt.MajorProperty = 'Function';
    sabt.ArrangePortMethod{ 1 } = 1;
%     sabt.RollPropertyMethod =  - 1;
    sabt.DataTypeMethod = [  ];

    btlogic = RegBlk_LogicalOperator;
    sabt.Inherit( btlogic,  ...
                  'BlockSize', 'AutoSizeMethod', 'LayoutSize', 'PlusMethod', 'MinusMethod', 'CleanMethod' );
end 


function [ actrec, success ] = routine_minmax( cmdstr, console )
    actrec = saRecorder;
    success = false;
    btobj = console.MapTo( 'MinMax' );
    cmdpsr = saCmdParser( cmdstr, btobj.RoutinePattern );

    switch cmdpsr.PatternStr
        case { 'min' }
            opsym = 'Min';
        case { 'max' }
            opsym = 'Max';
        otherwise
    end 

    pvpair = { 'Function', opsym };
    actrec = Routines.dynamicinport( btobj, cmdpsr.OptionStr, '', 'Function', opsym );
    success = true;
end