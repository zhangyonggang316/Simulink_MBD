%-------------------------------------------------------------------------------------------
%   �� �� ����RegBlk_LookupND.m
%   �ļ�������Lookup-n_Dģ��ע��
%   ��    ����V1.2.0
%   �޸ļ�¼��
%            2022/06/30    xuhongjiang01    �޸�refine�������������ơ���׼�趨����ɫ����
%            2022/07/13    xuhongjiang01    1��ģ���С��[50,50]�޸Ļ�Ĭ�ϴ�С[65,64]
%                                           2��ģ���С���������趨Ϊ-6
%            2022/07/30    xuhongjiang01    1��refine_method�޸���Table�̳����������ַ�����������
%                                           2��refine_method����TableDataTypeStrǿ���������ͼ̳�Table����
%                                           3��refine_method����ShowName�趨��Ĭ������ģ������
%                                           4��refine_method�޸�UseLastTableValue�趨���ָ�Ĭ��off
%                                           5��ע�͹����ͷţ�Ĭ����ʾTable��Ϊע��
%-------------------------------------------------------------------------------------------
function sabt = RegBlk_LookupND
    sabt = saBlock( 'Lookup_n-D' );

    sabt.RoutineMethod = @routine_lookupnd;
    sabt.RoutinePattern = '^(lookup|lu|l)';
    sabt.RoutinePriority = 60;

    sabt.MajorProperty = { 'BreakpointsForDimension1', '_AX';'Table', '' };
    sabt.DictRenameMethod = { 'Table', 'BreakpointsForDimension1', 'BreakpointsForDimension2', 'BreakpointsForDimension3', 'BreakpointsForDimension4' };

    sabt.DefaultParameters = { 'ExtrapMethod', 'Clip' };

    sabt.PropagateUpstreamStringMethod = @upstream_propagate;
    sabt.PropagateDownstreamStringMethod = 'Table';
    sabt.InportStringMethod = @getinportstring_lookupnd;
    sabt.OutportStringMethod = 'Table';
    sabt.AnnotationMethod = @lookupnd_annotation;
    sabt.RefineMethod = @refine_method;

    sabt.BlockPreferOption.Annotation = true;
    sabt.BlockPreferOption.Refine = false;

    sabt.BlockSize = [ 65, 64 ];
    sabt.AutoSizeMethod = -6;
end 

function actrec = upstream_propagate( blkhdl, instr )
    actrec = saRecorder;
    ndimstr = get_param( blkhdl, 'NumberOfTableDimensions' );
    if ndimstr == '1'
        actrec.SetParam( blkhdl, 'BreakpointsForDimension1', [ instr, '_AX' ], 'Table', instr );
    end 
end 

function actrec = refine_method( blkhdl )
    actrec = saRecorder;
    tbl = get_param( blkhdl, 'Table' );
    tabledem = get_param( blkhdl, 'NumberOfTableDimensions' );
    if ~isempty( tbl ) && tbl( 1 ) ~= '['   %��Table���ҷ�������ʽʱ�������趨����
        if strcmp( tabledem, '1' )
            actrec.SetParam( blkhdl, 'Name', tbl, 'ShowName','off','BackgroundColor', 'orange', 'ForegroundColor', 'black', ...
                                     'ExtrapMethod', 'Clip','UseLastTableValue','off','InputSameDT', 'off', ...
                                     'TableDataTypeStr','Inherit: Inherit from ''Table data''',...                                     
                                     'BreakpointsForDimension1DataTypeStr','Inherit: Inherit from ''Breakpoint data''',...
                                     'OutDataTypeStr', 'Inherit: Inherit from ''Table data''');
        elseif strcmp( tabledem, '2' )
            actrec.SetParam( blkhdl, 'Name', tbl, 'ShowName','off','BackgroundColor', 'orange', 'ForegroundColor', 'black', ...
                                     'ExtrapMethod', 'Clip','UseLastTableValue','off','InputSameDT', 'off', ...
                                     'TableDataTypeStr','Inherit: Inherit from ''Table data''',...                                     
                                     'BreakpointsForDimension1DataTypeStr','Inherit: Inherit from ''Breakpoint data''',...
                                     'BreakpointsForDimension2DataTypeStr','Inherit: Inherit from ''Breakpoint data''',...
                                     'OutDataTypeStr', 'Inherit: Inherit from ''Table data''');
        end
    end 
end 

function [ actrec, success ] = routine_lookupnd( cmdstr, console )
    actrec = saRecorder;
    success = false;
    btobj = console.MapTo( 'Lookup_n-D' );

    cmdpsr = saCmdParser( cmdstr, btobj.RoutinePattern );
    ndimstr = cmdpsr.OptionStr( 1 );
    if isnan( str2double( ndimstr ) )
        success = false;
        return ;
    end 


    cmdpsr.OptionStr( 1 ) = '';
    cmdpsr.OptionStr = strtrim( cmdpsr.OptionStr );
    [ vals, bclean ] = cmdpsr.ParseMultiValues;
    if ~bclean
        [ actrec, success ] = deal( saRecorder, false );
        return ;
    end 

    pvpair = { 'NumberOfTableDimensions', ndimstr };

    if isempty( vals )
    elseif numel( vals ) == 1
        if ndimstr == '1'
            pvpair = [ pvpair, 'Table', vals{ 1 },  ...
            'BreakpointsForDimension1', [ vals{ 1 }, '_AX' ] ];
        elseif ndimstr == '2'
        pvpair = [ pvpair, 'Table', vals{ 1 },  ...
            'BreakpointsForDimension1', [ vals{ 1 }, '_AX' ],  ...
            'BreakpointsForDimension2', [ vals{ 1 }, '_AY' ] ];
        else 
        end 
    elseif numel( vals ) == 2
        if ndimstr == '1'
            pvpair = [ pvpair, 'Table', vals{ 1 },  ...
            'BreakpointsForDimension1', vals{ 2 } ];
        elseif ndimstr == '2'
            pvpair = [ pvpair, 'Table', vals{ 1 },  ...
            'BreakpointsForDimension1', [ vals{ 2 }, '_AX' ],  ...
            'BreakpointsForDimension2', [ vals{ 2 }, '_AY' ] ];
        else 
        end 
    elseif numel( vals ) == 3
        if ndimstr == '1'
            pvpair = [ pvpair, 'Table', vals{ 1 },  ...
            'BreakpointsForDimension1', vals{ 2 } ];
        elseif ndimstr == '2'
            pvpair = [ pvpair, 'Table', vals{ 1 },  ...
            'BreakpointsForDimension1', vals{ 2 },  ...
            'BreakpointsForDimension2', vals{ 3 } ];
        else 
        end 
    else 
    end 
    actrec + btobj.GenericContextAdd( pvpair{ : } );
    success = true;

end 

function thestr = getinportstring_lookupnd( pthdl )
    ptnum = get_param( pthdl, 'PortNumber' );
    parblk = get_param( pthdl, 'Parent' );
    thestr = get_param( parblk, [ 'BreakpointsForDimension', int2str( ptnum ) ] );
end 

function lookupnd_annotation( blkhdl )
    actrec = saRecorder;
    ndimstr = get_param( blkhdl, 'NumberOfTableDimensions' );
    if ndimstr == '1'
        attrstr = sprintf( '%%<Table>' );
    elseif ndimstr == '2'
        attrstr = sprintf( '%%<Table>' );
    else 
    end 
    actrec.SetParam( blkhdl, 'AttributesFormatString', attrstr );    % ע������������ͳһʹ��Table���ƣ�2022/07/30
end