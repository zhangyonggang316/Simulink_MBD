%-------------------------------------------------------------------------------------------
%   �� �� ����RegBlk_CANUnpack.m
%   �ļ�������CANUnpackģ��ע��
%   ��    ����V1.0.0
%   �޸ļ�¼��
%-------------------------------------------------------------------------------------------
function sabt = RegBlk_CANUnpack

    sabt = saBlock( 'canmsglib/CAN Unpack' );

    sabt.OutportStringMethod = @outport_string_canunpack;

end 


function thestr = outport_string_canunpack( pthdl )
    ptnum = get_param( pthdl, 'PortNumber' );
    parblk = get_param( pthdl, 'Parent' );
    mskwsvars = get_param( parblk, 'MaskWSVariables' );
    portvar = mskwsvars( strcmp( { mskwsvars.Name }, 'port' ) ).Value;

    thestr = portvar( 1 + ptnum ).label;
end