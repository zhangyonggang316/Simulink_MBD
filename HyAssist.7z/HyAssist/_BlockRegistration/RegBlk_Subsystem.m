function sabt = RegBlk_Subsystem

    sabt = saBlock( 'SubSystem' );

    sabt.RoutinePattern = '^(ss|subsys|subsystem)';
    sabt.RoutineMethod = @routine_subsystem;
    sabt.MajorProperty = 'Name';
    sabt.PropertyList = { 'Name' };

    ssproto = RegProtoBlk_Subsystem;
    sabt.UseProto( ssproto );
end 

function [ actrec, success ] = routine_subsystem( cmdstr, console )
    actrec = saRecorder;
    success = false;
    btobj = console.MapTo( 'SubSystem' );
    srchdls = saFindSystem( gcs, 'line_sender' );
    dsthdls = saFindSystem( gcs, 'inport_unconnected' );

    optstr = regexprep( cmdstr, '^(ss|subsys|subsystem)', '', 'once' );
    iptnum = regexp( optstr, 'in?(\d+)', 'tokens', 'once' );
    if ~isempty( iptnum )
        iptnum = str2double( iptnum{ 1 } );
        optstr = regexprep( optstr, 'in?(\d+)', '', 'once' );
    else 
    if ~isempty( srchdls )
        iptnum = numel( srchdls );
    else 
        iptnum = 1;
    end 
    end 
    optnum = regexp( optstr, 'o(?:ut)?(\d+)', 'tokens', 'once' );
    if ~isempty( optnum )
        optnum = str2double( optnum{ 1 } );
        optstr = regexprep( optstr, 'o(?:ut)?(\d+)', '', 'once' );
    else 
        if ~isempty( dsthdls )
            optnum = numel( dsthdls );
        else 
            optnum = 1;
        end 
    end 
    if  contains( optstr, 'fc' ) 
        fc = true;
        optstr = regexprep( optstr, 'fc', '', 'once' );
    else 
        fc = false;
    end 
    if  contains( optstr, 'en' ) 
        en = true;
        optstr = regexprep( optstr, 'en', '', 'once' );
    else 
        en = false;
    end 
    if ~isempty( regexp( optstr, 'atomic|atom|atm|atmc', 'once' ) )
        atomic = 'on';
        optstr = regexprep( optstr, 'atomic|atom|atm|atmc', '', 'once' );
    else 
        atomic = 'off';
    end 
    tmp = strtrim( optstr );
    if ~isempty( tmp )
        subsysname = tmp;
    else 
        subsysname = 'SubSystem';
    end 


    [ actrec2, block ] = btobj.AddBlock( subsysname,  ...
    'TreatAsAtomicUnit', atomic );
    actrec + actrec2;


    subsys = getfullname( block );

    pos1 = [ 110, 103 ];
    inportbt = console.MapTo( 'Inport' );
    inportbt.AddBlockArray( pos1, iptnum, [ subsys, '/In' ] );

    pos2 = [ 360, 103 ];
    outportbt = console.MapTo( 'Outport' );
    outportbt.AddBlockArray( pos2, optnum, [ subsys, '/Out' ] );

    if fc
        trigbt = console.MapTo( 'TriggerPort' );
        ltpos = [ 150, 30 ];blkpos = [ ltpos, ltpos + trigbt.BlockSize ];
        trigbt.AddBlock( [ subsys, '/Trigger' ], blkpos );
    end 

    if en
        enablebt = console.MapTo( 'EnablePort' );
        ltpos = [ 200, 30 ];blkpos = [ ltpos, ltpos + enablebt.BlockSize ];
        enablebt.AddBlock( [ subsys, '/Enable' ], blkpos );
    end 

    btobj.AutoSize( block );
    
    if ~isempty( srchdls )
        actrec.MultiAutoLine( srchdls, block );
        actrec + btobj.PropagateUpstreamString( block );
    end
    
    if ~isempty( dsthdls )
        actrec.MultiAutoLine( block, dsthdls );
        actrec + btobj.PropagateDownstreamString( block );
    end 
    success = true;
end
