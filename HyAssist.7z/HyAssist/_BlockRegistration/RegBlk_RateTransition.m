function sabt = RegBlk_RateTransition
    
    sabt = saBlock( 'RateTransition' );
    
    sabt.RoutineMethod = 'num_only';
    sabt.RoutinePattern = '^(ratetransition|rate|rt)';
    sabt.MajorProperty = '';
    sabt.BlockSize = [ 30, 30 ];

end