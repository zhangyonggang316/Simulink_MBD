function sabt = RegBlk_Abs

    sabt = saBlock( 'Abs' );
    sabt.RoutinePattern = '^abs';
    sabt.RoutineMethod = 'num_only';
    sabt.BlockSize = [ 30, 30 ];

end 