function sabt = RegBlk_From
    sabt = saBlock( 'From' );
    sabt.RoutineMethod = 'majorprop_str_num';
    sabt.RoutinePattern = '^from';
    sabt.BroBlockType = { 'Goto', 'GotoTagVisibility' };
    sabt.CreateBroBlockMethod =  -1;
    sabt.ConnectPort = [ 0, 1 ];
    sabt.MajorProperty = 'GotoTag';
    sabt.DictRenameMethod = 1;
    sabt.PropagateUpstreamStringMethod = -1;
    sabt.PropagateDownstreamStringMethod = 'GotoTag';
    sabt.OutportStringMethod = 'GotoTag';
    sabt.InportStringMethod = -1;
    sabt.RefineMethod = @Refine_Method;
    sabt.ColorMethod = { -1, false };
    sabt.BlockSize = [ 100, 14 ];
    sabt.LayoutSize.VerticalMargin = 14;
    sabt.LayoutSize.CharWidth = 6;
    sabt.AutoSizeMethod = -4;   %-2
    sabt.GetBroMethod = @saFindBroBlocks;
end 

function actrec = Refine_Method( BlkHndl )
    actrec = saRecorder;
    tag = get_param( BlkHndl, 'GotoTag' );
    newval = [ tag, '_', get_param( BlkHndl, 'BlockType' ) ];
    actrec.SetParamHighlight( BlkHndl, 'Name', newval,'BackgroundColor','green','ShowName','off'   );
end 


function broblks = get_bro_blocks( BlkHndl )
end