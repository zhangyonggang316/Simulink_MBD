function sabt = RegBlk_Saturation
    sabt = saBlock( 'Saturate' );
    sabt.RoutineMethod = 'multiprop';
    sabt.RoutinePattern = '^(saturate|sat)';


    sabt.MajorProperty = { 'LowerLimit', '_Lo';'UpperLimit', '_Hi' };
    sabt.DictRenameMethod = { 'UpperLimit', 'LowerLimit' };

    sabt.PropagateUpstreamStringMethod = @set_string;
    sabt.PropagateDownstreamStringMethod = @set_string;
    sabt.InportStringMethod = @inport_string;
    sabt.AnnotationMethod = '%<LowerLimit> - %<UpperLimit>';

    sabt.BlockSize = [ 30, 30 ];

    sabt.BlockPreferOption.Annotation = true;

    sabt.DataTypeMethod = [  ];
    sabt.DefaultDataType = 'Inherit: Same as input';

end 

function thestr = inport_string( pthdl, appdata )
    ptnum = get_param( pthdl, 'PortNumber' );
    parblk = get_param( pthdl, 'Parent' );
    parpts = get_param( parblk, 'PortHandles' );
    outstr = appdata.Console.GetDownstreamString( parpts.Outport );
    thestr = [ outstr, 'Raw' ];
end 

function actrec = set_string( blkhdl, instr )
    actrec = saRecorder;
    actrec.SetParam( blkhdl, 'UpperLimit', [ instr, '_Hi' ] );
    actrec.SetParam( blkhdl, 'LowerLimit', [ instr, '_Lo' ] );
end