%-------------------------------------------------------------------------------------------
%   �� �� ����RegBlk_RelationalOperator.m
%   �ļ�������RelationalOperatorģ��ע��
%   ��    ����V1.0.1
%   �޸ļ�¼��
%            2022/07/31    xuhongjiang01    �޸�ΪĬ�ϳߴ�[30,31]��������С�����ָ�Ϊ-9
%-------------------------------------------------------------------------------------------
function sabt = RegBlk_RelationalOperator

    sabt = saBlock( 'RelationalOperator' );

    sabt.RoutinePattern = '^[><=~]+';
    sabt.RoutineMethod = @routine_compare;
    sabt.RoutinePrompts = { '==', '~=', '<', '<=', '>=', '>' };

    sabt.MajorProperty = 'Operator';
    % sabt.RollPropertyMethod =  - 1;     %����ѭ���������ԣ����������
    sabt.RefineMethod = @refine_RelOpr;

    sabt.BlockPreferOption.AutoDataType = false;

    sabt.BlockSize = [ 30, 31 ];
    sabt.AutoSizeMethod =  -9;
    sabt.DataTypeMethod = [  ];
end 

function actrec = refine_RelOpr( blkhdl )
    actrec = saRecorder;
    actrec.SetParamHighlight( blkhdl, 'ShowName','off' );
end 

function [ actrec, success ] = routine_compare( cmdstr, console )
    actrec = saRecorder;
    success = false;
    btobj = console.MapTo( 'RelationalOperator' );
    cmdpsr = saCmdParser( cmdstr, btobj.RoutinePattern );
    if ~ismember( cmdpsr.PatternStr, { '==', '~=', '<', '<=', '>=', '>' } )
        return ;
    end 
    option1.AutoDataType = false;
    [ actrec2, block ] = btobj.AddBlock( 'RelationalOperator', 'Operator', cmdpsr.PatternStr, option1 );
    actrec.Merge( actrec2 );
    actrec.SetParamHighlight( block, 'OutDataTypeStr','boolean' );
    if isempty( cmdpsr.OptionStr )
        srchdls = saFindSystem( gcs, 'line_sender' );
        if ~isempty( srchdls )
            actrec.MultiAutoLine( srchdls, block );
        end 
    else 
        btobjcnst = console.MapTo( 'Constant' );
        pts = get_param( block, 'PortHandles' );
        option2.PropagateString = false;
        actrec + btobjcnst.AddBlockToPort( pts.Inport( 2 ), option2, 'Value', cmdpsr.OptionStr );
    end 
    success = true;
end