function saLoadLib( libname )
if ~bdIsLoaded( libname )

load_system( libname );

end 
end 
% Decoded using De-pcode utility v1.2 from file /tmp/tmpl8SYgl.p.
% Please follow local copyright laws when handling this file.

