function AddLine_LineToNoSrcLine( obj, srchdl, dsthdl, overlap_offset )

    if nargin < 4
        overlap_offset = [ 0, 0 ];
    end 
    dstpos = get_param( dsthdl, 'Points' );
    points_layout = saLineRouteLineToDst( srchdl, dstpos( 1, : ), overlap_offset );
    parsys = get_param( srchdl, 'Parent' );

    lnname = regexprep( get_param( srchdl, 'Name' ), '[<>]', '' );
    srcpt = get_param( srchdl, 'SrcPortHandle' );
    if srcpt > 0
        resolveflg = get_param( srcpt, 'MustResolveToSignalObject' );
    else 
        resolveflg = 'off';
    end 

    obj.AddLine( parsys, round( points_layout ) );

    if ~isempty( lnname )
        set_param( newln, 'Name', lnname );
        if srcpt > 0
            set_param( srcpt, 'MustResolveToSignalObject', resolveflg );
        end 
    end 

end