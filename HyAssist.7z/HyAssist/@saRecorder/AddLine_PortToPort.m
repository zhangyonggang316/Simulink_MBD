function AddLine_PortToPort( obj, srchdl, dsthdl )
    parsys = get_param( get_param( srchdl, 'Parent' ), 'Parent' );
    obj.AddLine( parsys, srchdl, dsthdl );
end