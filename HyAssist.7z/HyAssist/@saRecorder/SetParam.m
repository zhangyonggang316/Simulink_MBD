function SetParam( obj, varargin )
    objhndl = varargin{ 1 };
    if ischar( objhndl )
        objhdl = get_param( objhndl, 'Handle' );
    end 
    for i = 2:2:numel( varargin )
        sa = saAction( 'set_param', objhndl, varargin{ i }, varargin{ i + 1 } );
        obj.PushItem( sa );
    end 
end
