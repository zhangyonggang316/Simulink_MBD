function block = AddBlock( obj, varargin )

    N = struct( 'flg', false, 'extra', '' );
    S = struct( 'flg', true, 'extra', '' );
    D = struct( 'flg', false, 'extra', '' );
    optstr = varargin{ 1 };
    opts = regexp( optstr, '\-([a-zA-Z])(\w*)', 'tokens' );
    for i = 1:numel( opts )
        tmp = struct( 'flg', logical( opts{ i }{ 1 } - lower( opts{ i }{ 1 } ) ), 'extra', opts{ i }{ 2 } );
        eval( [ upper( opts{ i }{ 1 } ), '=tmp;' ] );
    end 
    src = varargin{ 2 };
    if D.flg
        dst = varargin{ 3 };
    else 
        dst = [ gcs, '/', varargin{ 3 } ];
    end 
    if isempty( strfind( src, '/' ) )
        src = [ 'built-in/', src ];
    end 
    prop = varargin( 4:end  );
    if S.flg
        prop = [ prop, { 'Selected', 'on' } ];
    else 
        prop = [ prop, { 'Selected', 'off' } ];
    end 
    if N.flg
        prop = [ prop, { 'ShowName', 'on' } ];
    else 
        prop = [ prop, { 'ShowName', 'off' } ];
    end 
    sa = saAction( 'add_block', src, dst, prop{ : } );
    obj.PushItem( sa );
    block = sa.Handle;
end