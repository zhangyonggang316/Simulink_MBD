function AddLine_LineToPort( obj, SrcHndl, DstHndl, overlap_offset )

    if nargin < 4
        overlap_offset = [ 0, 0 ];
    end 
    DstPos = get_param( DstHndl, 'Position' );

    points_layout = saLineRouteLineToDst( SrcHndl, DstPos, [ overlap_offset + [ -10, 0 ] ] );
    parsys = get_param( SrcHndl, 'Parent' );

    LinName = regexprep( get_param( SrcHndl, 'Name' ), '[<>]', '' );
    SrcPortHndl = get_param( SrcHndl, 'SrcPortHandle' );
    if SrcPortHndl > 0
        ResolveFlag = get_param( SrcPortHndl, 'MustResolveToSignalObject' );
    else 
        ResolveFlag = 'off';
    end 

    newln = obj.AddLine( parsys, round( points_layout ) );

    if ~isempty( LinName )
        set_param( newln, 'Name', LinName );
        if SrcPortHndl > 0
            set_param( SrcPortHndl, 'MustResolveToSignalObject', ResolveFlag );
        end 
    end 
end