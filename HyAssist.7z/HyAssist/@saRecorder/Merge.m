function Merge( obj, obj2 )
    obj.ActionList = [ obj2.ActionList;obj.ActionList ];
end