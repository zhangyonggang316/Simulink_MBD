function actrec = Adapt( obj, BlkHndl, option )
    actrec = saRecorder;
    if nargin < 3
        console = obj.Console;
        if ~isempty( console )
            option = console.RunOption;
        else 
            return ;
        end 
    end
    
    if option.AutoSize && ~isempty( obj.AutoSizeMethod )
        actrec.Merge( obj.AutoSize( BlkHndl ) );
    end 
    
    if option.Color && ~isempty( obj.ColorMethod )
        actrec.Merge( obj.Color( BlkHndl ) );
    end
    
    if option.Annotation && ~isempty( obj.AnnotationMethod )
        actrec.Merge( obj.Annotate( BlkHndl ) );
    end
    
    if option.Refine && ~isempty( obj.RefineMethod )
        actrec.Merge( obj.Refine( BlkHndl ) );
    end 

    if ~isempty( obj.Console ) && isfield( obj.Console.SessionPara, 'DataType' ) && ~isempty( obj.Console.SessionPara.DataType )
        actrec.Merge( obj.SetDataType( BlkHndl, obj.Console.SessionPara.DataType ) );
    elseif option.AutoDataType && ~isempty( obj.DataTypeMethod )
        actrec.Merge( obj.SetDataType( BlkHndl ) );
    else 
    end 
end