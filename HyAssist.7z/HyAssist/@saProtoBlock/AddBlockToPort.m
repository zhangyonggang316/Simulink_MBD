function [ actrec, blkhdl ] = AddBlockToPort( obj, pthdl, varargin )

    actrec = saRecorder;

    if pthdl < 0
        return ;
    end


    if strcmp( get_param( pthdl, 'type' ), 'block' )
        pts = get_param( pthdl, 'PortHandles' );
        if numel( pts.Inport ) == 1
            pthdl = pts.Inport;
        elseif numel( pts.Outport ) == 1
            pthdl = pts.Outport;
        else 
            return;
        end 
    end 


    local_opt = struct(  ...
    'HorizontalMargin', obj.LayoutSize.HorizontalMargin,  ...
    'GetMarginByMouse', obj.Console.RunOption.GetMarginByMouse,  ...
    'PropagateString', true );
    [ option, argsin, optarg ] = override_option( varargin, obj, local_opt );

    xy0 = saGetMousePosition;
    ptpos = get_param( pthdl, 'Position' );
    defaultHM = option.HorizontalMargin;
    if strcmp( get_param( pthdl, 'PortType' ), 'inport' ) && option.GetMarginByMouse
        HM = max( option.HorizontalMargin, ptpos( 1 ) - xy0( 1 ) );
    elseif strcmp( get_param( pthdl, 'PortType' ), 'outport' ) && option.GetMarginByMouse
        HM = max( option.HorizontalMargin, xy0( 1 ) - ptpos( 1 ) );
    else 
        HM = option.HorizontalMargin;
    end 

    optarg.AutoSize = false;
    optarg.AutoDataType = false;
    optarg.Refine = false;

    i_szpara = find( cellfun( @isnumeric, argsin ), 1 );
    if ~isempty( i_szpara )
        W = argsin{ i_szpara }( 1 );H = argsin{ i_szpara }( 2 );
        blockpos = calculate_block_position( pthdl, HM, W, H, defaultHM );
        argsin{ i_szpara } = blockpos;
    else 
        blksize = obj.GetBlockSize;
        W = blksize( 1 );
        H = blksize( 2 );
        blockpos = calculate_block_position( pthdl, HM, W, H, defaultHM );
        argsin = [ blockpos, argsin ];
    end 
    %���������inport�������ж��Ƿ��Ѵ�����ͬ����ģ�飬���У�����From���棬����Goto����һ������Goto
    if strcmp('Inport',obj.BlockType)
        blkostr = obj.Console.GetDownstreamString(pthdl);
    end
    
    %�����߼�����

    [ actrec2, blkhdl ] = obj.AddBlock( optarg, argsin{ : } );
    actrec.Merge( actrec2 );


    parasys = get_param( blkhdl, 'Parent' );
    blkpts = get_param( blkhdl, 'PortHandles' );
    if strcmp( get_param( pthdl, 'PortType' ), 'inport' )
        if numel( blkpts.Outport ) > 0 && obj.ConnectPort( 2 )
            actrec.AddLine( parasys, blkpts.Outport( obj.ConnectPort( 2 ) ), pthdl, '' );
            if option.PropagateString && ~isempty( obj.PropagateDownstreamStringMethod )
                actrec.Merge( obj.PropagateDownstreamString( blkhdl ) );
            end 
        end 
    else 
        if numel( blkpts.Inport ) > 0 && obj.ConnectPort( 1 )
            actrec.AddLine( parasys, pthdl, blkpts.Inport( obj.ConnectPort( 1 ) ), '' );
            if option.PropagateString && ~isempty( obj.PropagateUpstreamStringMethod )
                actrec.Merge( obj.PropagateUpstreamString( blkhdl ) );
            end 
        end 
    end 
    actrec + obj.Adapt( blkhdl, option );

end 


function blockpos = calculate_block_position( pthdl, HM, W, H, defaultHM )



    basepos = get_param( pthdl, 'Position' );
    if strcmp( get_param( pthdl, 'PortType' ), 'inport' )
        if verLessThan( 'Simulink', '8.0' ) && basepos( 1 ) < HM
            HM = defaultHM;
        end 
        blockpos = saRectifyPos( [ basepos( 1 ) - HM - W,  ...
        basepos( 2 ) - H / 2,  ...
        basepos( 1 ) - HM,  ...
        basepos( 2 ) + H / 2 ] );
    else 
        blockpos = [ basepos( 1 ) + HM,  ...
        basepos( 2 ) - H / 2,  ...
        basepos( 1 ) + HM + W,  ...
        basepos( 2 ) + H / 2 ];
    end 
end

