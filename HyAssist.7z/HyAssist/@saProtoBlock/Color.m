function actrec = Color( obj, BlkHndl, colorspec )

    actrec = saRecorder;
    if nargin < 3
        color_method = obj.ColorMethod;
    else 
        color_method = colorspec;
    end 
    if isempty( color_method )
        return ;
    else 
        if iscell( color_method )
            actrec + SetColor( color_method{ 1 }, BlkHndl, 'ForegroundColor' );
            actrec + SetColor( color_method{ 2 }, BlkHndl, 'BackgroundColor' );
        else 
            actrec + SetColor( color_method, BlkHndl, 'ForegroundColor' );
        end 
    end 

end 


function actrec = SetColor( colorspec, BlkHndl, fbprop )
    if nargin < 3
        fbprop = 'ForegroundColor';
    end 
    actrec = saRecorder;
    if isempty( colorspec ) || ( isscalar( colorspec ) && ~colorspec )
        return ;
    elseif ischar( colorspec )
        actrec.SetParam( BlkHndl, fbprop, colorspec );
    else 
        if isnumeric( colorspec )
            if numel( colorspec ) == 3
                actrec.SetParam( BlkHndl, fbprop, mat2str( colorspec ) );
            elseif colorspec < 0
                actrec.SetParam( BlkHndl, fbprop, mat2str( rand( 1, 3 ) ) );
            else 
            end 
        elseif isa( colorspec, 'function_handle' )
            nn = nargout( colorspec );
            if nn ~= 0
                actrec.Merge( colorspec( BlkHndl ) );
            else 
                colorspec( BlkHndl );
            end 
        else 
        end 
    end 
end 