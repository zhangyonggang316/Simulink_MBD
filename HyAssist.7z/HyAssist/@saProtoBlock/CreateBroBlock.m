function actrec = CreateBroBlock( obj, blkhdl, varargin )

    actrec = saRecorder;
    cr_pair_method = obj.CreateBroBlockMethod;

    if isempty( obj.BroBlockType )
    return ;
    elseif isa( cr_pair_method, 'function_handle' )
    nn = nargout( cr_pair_method );
    ni = nargin( cr_pair_method );
    varlist = [ blkhdl, varargin ];
    if nn ~= 0
    actrec.Merge( cr_pair_method( varlist{ 1:ni } ) );
    else 
    cr_pair_method( varlist{ 1:ni } );
    end 
    else 

    i_strarg = cellfun( @isstr, varargin );
    propvals = varargin( i_strarg );
    i_fh = cellfun( @( c )isa( c, 'function-handle' ), varargin );
    postfun = varargin( i_fh );
    i_num = cellfun( @( c )isnumeric( c ), varargin );
    cnnttype = varargin( i_num );
    [ ~, ~, optarg ] = override_option( varargin, obj );
    optarg.Color = false;
    optarg.AutoSize = false;

    majorval = get_param( blkhdl, obj.GetMajorProperty( blkhdl ) );
    refpos = get_param( blkhdl, 'Position' );
    fcolor = get_param( blkhdl, 'ForegroundColor' );
    bcolor = get_param( blkhdl, 'BackgroundColor' );
    refsz = refpos( 3:4 ) - refpos( 1:2 );
    xy0 = refpos( 3:4 ) + ceil( [ refsz( 1 ) / 3, obj.LayoutSize.VerticalMargin ] );
    if isempty( cnnttype )
    cnnttype = ~obj.ConnectPort;
    else 
    cnnttype = cnnttype{ 1 };
    end 
    broblktyps = cellstr( obj.BroBlockType );
    for i = 1:numel( broblktyps )
    brobtobj = obj.Console.MapTo( broblktyps{ i } );
    if ~any( xor( brobtobj.ConnectPort, cnnttype ) )
    actrec + brobtobj.AddBlock( xy0, refsz, optarg,  ...
                                obj.GetMajorProperty( blkhdl ), majorval,  ...
                                'ForegroundColor', fcolor,  ...
                                'BackgroundColor', bcolor,  ...
                                'Selected', 'on',  ...
                                propvals{ : },  ...
                                postfun{ : } );
    break ;
    end 
    end 
    set_param( blkhdl, 'Selected', 'off' );
    end
    
end