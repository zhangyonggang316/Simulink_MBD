%--------------------------------------------------------------------------
%   �� �� ����GetMajorProperty.m
%   �ļ���������ȡ��Ҫ����
%   ��    ����V1.0
%   �޸ļ�¼��
%--------------------------------------------------------------------------
function majprop = GetMajorProperty( obj, BlkHndl )
    if isempty( obj.MajorProperty )
        majprop = 'Name';
    elseif ischar( obj.MajorProperty )
        majprop = obj.MajorProperty;
    elseif iscell( obj.MajorProperty )
        majprop = obj.MajorProperty{ 1 };
    elseif isnumeric( obj.MajorProperty )
        dlgparas = fieldnames( get_param( BlkHndl, 'DialogParameters' ) );
        if ~isempty( dlgparas )
            if obj.MajorProperty ==  - 1
                majprop = dlgparas{ 1 };
            else 
                majprop = dlgparas{ i };    %������
            end 
        else 
            majprop = '';
        end 
    elseif isa( obj.MajorProperty, 'function_handle' )
        GetMajPropMethod = obj.MajorProperty;
        majprop = GetMajPropMethod( BlkHndl );
    else 
        majprop = 'Name';
    end
end