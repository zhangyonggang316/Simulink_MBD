function actrec = Plus( obj, blkhdl, operand )
    actrec = saRecorder;
    if isempty( obj.PlusMethod )
        return ;
    else 
    bkups = obj.TemporaryCurrentBlockBased( blkhdl );

    if isequal( obj.PlusMethod,  - 1 )
    elseif isa( obj.PlusMethod, 'function_handle' )
        nn = nargout( obj.PlusMethod );
        ni = nargin( obj.PlusMethod );
        args = { blkhdl, operand, obj.Console };
        if nn ~= 0
            actrec.Merge( obj.PlusMethod( args{ 1:ni } ) );
        else 
            obj.PlusMethod( args{ 1:ni } );
        end 
    else 
    end 
    actrec + obj.AutoSize( blkhdl );

    obj.TemporaryCurrentBlockBased( bkups );
    end 
end