function actrec = PropagateDownstreamString( obj, blkhdl )
    actrec = saRecorder;
    down_prpg_method = obj.PropagateDownstreamStringMethod;
    if isempty( down_prpg_method )
        return ;
    end 

    console = obj.Console;
    if isstruct( down_prpg_method )
        pts = get_param( blkhdl, 'PortHandles' );
        blkostr = console.GetDownstreamString( pts.Outport( down_prpg_method.StringPortNum ) );
        down_prpg_method = down_prpg_method.Method;
    else 
        blkostr = console.GetDownstreamString( blkhdl );
    end 

    if isa( down_prpg_method, 'function_handle' )
        nn = nargout( down_prpg_method );
        ni = nargin( down_prpg_method );
        argsin = { blkhdl, blkostr };
        if nn ~= 0
            actrec.Merge( down_prpg_method( argsin{ 1:ni } ) );
        else 
            down_prpg_method( argsin{ 1:ni } );
        end 
    elseif ischar( down_prpg_method ) && ~isempty( blkostr )
        if iscell( blkostr )
            blkostr = blkostr{ 1 };
        end 
        actrec.SetParam( blkhdl, down_prpg_method, blkostr );
    else 
    end
end
