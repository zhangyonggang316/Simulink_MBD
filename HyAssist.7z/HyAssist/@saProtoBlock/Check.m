function tf = Check( obj, BlkHndl )
    tf = false;
    if ~isa( obj.ProtoCheckMethod, 'function_handle' )
        return ;
    end 
    if ischar( BlkHndl )
        try 
            BlkHndl = get_param( BlkHndl, 'Handle' );
        catch 
            return;
        end 
    end 
    tf = obj.ProtoCheckMethod( BlkHndl );
end