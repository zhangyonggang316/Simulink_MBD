function [ actrec, blkhdl ] = InsertBlockToLine( obj, LineHndl, varargin )

    actrec = saRecorder;
    if LineHndl < 0
        return ;
    end

    local_opt = {  };
    [ option, varargin ] = override_option( varargin, obj, local_opt );

    newvars = varargin;
    i_para = find( cellfun( @isnumeric, varargin ), 1 );
    if isempty( i_para )
        cnntport = obj.ConnectPort;
    else 
        if ~isempty( varargin{ i_para } ) && numel( varargin{ i_para } ) == 2
            cnntport = varargin{ i_para };
            newvars( i_para ) = [  ];
        else 
            cnntport = obj.ConnectPort;
        end 
    end 

    xy0 = saGetMousePosition;
    x0 = xy0(1);
    y0 = xy0(2);
    lnpos = get_param( LineHndl, 'Points' );
    xln = [ min( lnpos( :, 1 ) ), max( lnpos( :, 1 ) ) ];
    blksz = obj.GetBlockSize;
    inside = @( rng, loc )( rng( 1 ) - loc ) * ( rng( 2 ) - loc ) < 0;
    if inside( xln, x0 )
        [ ln1pos, ln2pos, blkwd ] = xsplit_line( lnpos, x0 );
        blksz( 1 ) = min( blksz( 1 ), blkwd );
    elseif xln( 1 ) == xln( 2 )
        ysep = round( sum( lnpos( :, 2 ) ) / size( lnpos, 1 ) );
        ln1pos = [ lnpos( 1, : );[ xln( 1 ), ysep ];[ xln( 1 ) + 5, ysep ] ];
        ln2pos = [ [ xln( 1 ), ysep ];lnpos( end , : ) ];
    else 
        [ tmp, idx ] = max( abs( diff( lnpos( :, 1 ) ) ) );
        xa = lnpos( idx, 1 );xb = lnpos( idx + 1, 1 );
        xx = round( max( min( xa, xb ) + 5, ( xa + xb ) / 2 - blksz( 1 ) / 2 ) );
        [ ln1pos, ln2pos, blkwd ] = xsplit_line( lnpos, xx );
        blksz( 1 ) = min( blksz( 1 ), blkwd );
    end
    
    if ln2pos( 2, 1 ) < ln1pos( end , 1 )
        orient = 'left';
    else 
        orient = 'right';
    end 

    LineName = get_param( LineHndl, 'Name' );
    DstPorts = get_param( LineHndl, 'DstPortHandle' );
    ParSys = get_param( LineHndl, 'Parent' );
    LineInfo = Backup_LineInfo( LineHndl );

    actrec.DeleteLine( LineHndl );

    ltpos = [ ln1pos( end , 1 ), ceil( ln1pos( end , 2 ) - blksz( 2 ) / 2 ) ];
    [ actrec2, blkhdl ] = obj.AddBlock( saRectifyPos( ltpos ), blksz, newvars{ : }, 'Orientation', orient );
    actrec.Merge( actrec2 );
    set_param( blkhdl, 'Selected', 'on' );

    pthdls = get_param( blkhdl, 'PortHandles' );
    iptpos = get_param( pthdls.Inport( cnntport( 1 ) ), 'Position' );
    if size( ln1pos, 1 ) == 1
        newlnpos = [ ln1pos;ln1pos ];
    else 
        newlnpos = ln1pos;
    end 
    yofs = newlnpos( end , 2 ) - iptpos( 2 );
    blkpos = get_param( blkhdl, 'Position' );
    blkpos( [ 2, 4 ] ) = blkpos( [ 2, 4 ] ) + yofs;
    set_param( blkhdl, 'Position', saRectifyPos( blkpos ) );
    newlnpos( end , 1 ) = iptpos( 1 );
    newlnhdl = actrec.AddLine( ParSys, newlnpos );
    actrec.SetParam( newlnhdl, 'Name', LineName );

    optpos = get_param( pthdls.Outport( cnntport( 2 ) ), 'Position' );
    ln2pos( 1, : ) = ceil( ( ln2pos( 1, : ) + ln2pos( 2, : ) ) / 2 );
    if optpos( 2 ) == ln2pos( 1, 2 )
        newlnpos = [ optpos;ln2pos( end , : ) ];
    else 
        newlnpos = [ optpos;[ ln2pos( 1, 1 ), optpos( 2 ) ];ln2pos ];
    end 
    actrec.AddLine( ParSys, newlnpos );
    actrec + Redraw_Lines( ParSys, LineInfo.LineChildren );
end 


function [ ln1pos, ln2pos, wd ] = xsplit_line( lnpos, x0 )

    ln1pos = [  ];ln2pos = lnpos;wd = 0;
    for r = 1:size( lnpos, 1 ) - 1
        pa = lnpos( r, : );pb = lnpos( r + 1, : );
        if pa( 1 ) == x0
            ln1pos = lnpos( 1:r, : );
            ln2pos = lnpos( r:end , : );
            wd = 0;
            break ;
        elseif ( pa( 1 ) - x0 ) * ( pb( 1 ) - x0 ) <= 0
            y0 = ceil( pa( 2 ) + ( x0 - pa( 1 ) ) / ( pb( 1 ) - pa( 1 ) ) * ( pb( 2 ) - pa( 2 ) ) );
            ln1pos = [ lnpos( 1:r, : );[ x0, y0 ] ];
            ln2pos = [ [ x0, y0 ];lnpos( r + 1:end , : ) ];
            wd = ceil( abs( pb( 1 ) - pa( 1 ) ) * 0.618 );
            break ;
        else 
        end 
    end 
    if isempty( ln1pos )
    ln1pos = [ [ x0, ln2pos( 1, 2 ) ];ln2pos( 1, : ) ];
    end 
    wd = max( wd, 10 );
end 

%--------------------------------------------------------------------------
%   �� �� ����Backup_LineInfo(LineHndl)
%   ��������������Ϣ���ݱ���
%   �޸ļ�¼��
%           
%--------------------------------------------------------------------------
function LineInfo = Backup_LineInfo(LineHndl)
    LineInfo.Points = get_param( LineHndl, 'Points' );      %��ȡ�ߵĸ���������
    LineChilds = get_param( LineHndl, 'LineChildren' );     
    if isempty( LineChilds )
        LineInfo.LineChildren = [  ];
    else 
        for i = 1:numel( LineChilds )
            LineInfo.LineChildren( i ) = Backup_LineInfo( LineChilds( i ) );
        end 
    end 
end 

%--------------------------------------------------------------------------
%   �� �� ����Redraw_Lines(ParentSys,LineInfo)
%   �����������ػ���
%   �޸ļ�¼��
%           
%--------------------------------------------------------------------------
function actrec = Redraw_Lines(ParentSys,LineInfo)
    
    actrec = saRecorder;
    for Idx = 1:numel(LineInfo)
        actrec.AddLine(ParentSys, LineInfo(Idx).Points);
        if ~isempty(LineInfo(Idx).LineChildren)
            actrec + Redraw_Lines(ParentSys, LineInfo(Idx).LineChildren);
        end 
    end 
end 
