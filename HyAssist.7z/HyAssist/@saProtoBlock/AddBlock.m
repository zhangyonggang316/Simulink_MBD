function [ actrec, blkhdl ] = AddBlock( obj, varargin )

    actrec = saRecorder;
    if isempty( obj.SourcePath )
        blkhdl = [  ];
        return ;
    end 

    i_strarg = cellfun( @isstr, varargin );
    argstr = varargin( i_strarg );
    argnstr = varargin( ~i_strarg );

    if logical( rem( numel( argstr ), 2 ) )
        dst = argstr{ 1 };
        ovrdprops = argstr( 2:end  );
    else 
        dst = get_param( obj.GetSourcePath, 'Name' );
        ovrdprops = argstr;
    end 

    argnumeric = argnstr( cellfun( @isnumeric, argnstr ) );
    if isempty( argnumeric )
        xy0 = saGetMousePosition;
        blksize = obj.GetBlockSize;
        pos = [ xy0, xy0 + blksize ];
    elseif numel( argnumeric ) == 1
        if numel( argnumeric{ 1 } ) == 4
            pos = argnumeric{ 1 };
            blksize = pos( 3:4 ) - pos( 1:2 );
        elseif numel( argnumeric{ 1 } ) == 4
            xy0 = saGetMousePosition;
            blksize = argnumeric{ 1 };
            pos = [ xy0, xy0 + blksize ];
        else 
            xy0 = saGetMousePosition;
            blksize = obj.GetBlockSize;
            pos = [ xy0, xy0 + blksize ];
        end 
    else 
        xy0 = argnumeric{ 1 };
        blksize = argnumeric{ 2 };
        pos = [ xy0, xy0 + blksize ];
    end 


    if ~isempty( obj.Console ) && isfield( obj.Console.SessionPara, 'IndexOfMulti' )
        imulti = obj.Console.SessionPara.IndexOfMulti;
    else 
        imulti = 1;
    end 
    offset = ( imulti - 1 ) * [ 0, ( blksize( 2 ) + obj.LayoutSize.VerticalMargin ) ];
    pos = pos + [ offset, offset ];


    argfh = argnstr( cellfun( @( c )isa( c, 'function_handle' ), argnstr ) );
    if isempty( argfh )
        postfun = obj.PostAddMethod;
    else 
        postfun = argfh{ 1 };
    end 

    if  ~contains( dst, '/' ) 
        dst = [ gcs, '/', dst ];
    end 

    src = obj.GetSourcePath;

    sa = saAction( 'add_block', src, dst,  ...
                    'Position', pos,  ...
                    'ShowName', obj.BlockPreferOption.ShowName, 'Selected', obj.BlockPreferOption.Selected,  ...
                    obj.DefaultParameters{ : },  ...
                    ovrdprops{ : } );

    actrec.PushItem( sa );
    blkhdl = sa.Handle;

    if ~isempty( postfun )
        if nargout( postfun ) > 0
            actrec.Merge( postfun( blkhdl ) );
        else 
            postfun( blkhdl );
        end 
    end 

    option = override_option( argnstr, obj );
    actrec + obj.Adapt( blkhdl, option );
end
