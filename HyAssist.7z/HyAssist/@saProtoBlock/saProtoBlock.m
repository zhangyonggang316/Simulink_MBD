classdef saProtoBlock < saObject
    properties 
        ProtoType
        ProtoPriority = 10;
        ProtoCheckMethod
        ProtoProperty = {  };
        RoutinePattern
        RoutinePrompts = {  };
        RoutinePriority = 50;
        RoutineMethod
        RoutinePara = struct;
        MajorProperty = -1
        BroBlockType
        CreateBroBlockMethod
        GetBroMethod
        BlockSize
        LayoutSize = struct( 'HorizontalMargin', 40,  ...
                             'VerticalMargin', 30,  ...
                             'PortSpacing', 30,  ...
                             'CharWidth', 8,  ...
                             'ToLineOffset', [50,50] )
%         BlockPreferOption = struct( 'ShowName', 'off', 'Selected', 'off' )
        BlockPreferOption = struct( 'ShowName', 'off', 'Selected', 'off', 'BackgroundColor', 'white', 'ForegroundColor', 'black')
        PostAddMethod
        DefaultDataType = ''
        ConnectPort = [ 1, 1 ]
        PropagateUpstreamStringMethod
        PropagateDownstreamStringMethod
        OutportStringMethod
        InportStringMethod
        SetPropertyMethod = -1
        RollPropertyMethod
        AnnotationMethod
        RefineMethod
        DictRenameMethod
        StrReplaceMethod = 2
        AutoSizeMethod = -1
        AlignMethod = -1
        ColorMethod = -1
        CleanMethod
        DataTypeMethod = -1
        ArrangePortMethod = { [  ], [  ] }
        PlusMethod
        MinusMethod
    end 

    properties ( Constant )
        Dictionary = HY_DICTIONARY;
        ShowWaitbarThreshold = 15;
        StrReplaceDefaults = { 
                                'Name';'Value';'GotoTag';'DataStoreName';'InputValues';'Table';'mxTable';...
                                'BreakpointsData';'OutputSignals';'OutMax';'OutMin';'RowIndex';'ColumnIndex'; ...
                                'UserSpecifiedLogName';'AttributesFormatString';'Description';'Tag';'UpperLimit';'LowerLimit'; ...
                                'VariableName'; 'nam';'bp_nam';'val';'breakpoint_data';'table_data';'msg';'msgl';...
                                'row_nam';'col_nam';'row_breakpoint_data';'col_breakpoint_data';'varname'; ...
         };
    end 

    methods 
        function obj = saProtoBlock( varargin )
            obj = obj@saObject( 'protoblock' );
            if nargin > 0
                obj.ProtoType = varargin{ 1 };
                if varargin{ 1 }( 1 ) ~= '#'
                    obj.MapKey = [ '#', obj.ProtoType ];
                else 
                    obj.MapKey = obj.ProtoType;
                end 
            end 
        end 

        function varargout = Dispatch( obj, varargin )
            [ varargout{ 1:nargout } ] = obj.Console.Dispatch( varargin{ : } );
        end 

        function varargout = DispatchH( obj, varargin )
            [ varargout{ 1:nargout } ] = obj.Console.DispatchH( varargin{ : } );
        end 

    end 
end
