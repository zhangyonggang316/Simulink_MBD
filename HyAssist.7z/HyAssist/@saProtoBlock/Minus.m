function actrec = Minus( obj, BlkHndl, Operand )
    actrec = saRecorder;
    if isempty( obj.MinusMethod )
        return;
    else 
        if isequal( obj.MinusMethod,  - 1 )
        elseif isa( obj.MinusMethod, 'function_handle' )
            nn = nargout( obj.MinusMethod );
            if nn ~= 0
                actrec.Merge( obj.MinusMethod( BlkHndl, Operand ) );
            else 
                obj.MinusMethod( BlkHndl, Operand );
            end 
        else 
        end 
        actrec + obj.AutoSize( BlkHndl );
    end 
end
