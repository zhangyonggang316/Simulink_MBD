function [ option, args, optarg ] = override_option( args, btobj, local_opt )

    if nargin < 3
        local_opt = [  ];
    end 

    i_optarg = find( cellfun( @isstruct, args ), 1 );
    if ~isempty( i_optarg )
        optarg = args{ i_optarg };
        args( i_optarg ) = [  ];
    else 
        optarg = [  ];
    end 

    blkprefer = btobj.BlockPreferOption;
    if ~isempty( btobj.Console )
        consoledefault = btobj.Console.RunOption;
        sessionpara = btobj.Console.SessionPara;
    else 
        consoledefault = [  ];
        sessionpara = [  ];
    end 
    option = saOverrideOption( optarg, sessionpara, blkprefer, local_opt, consoledefault );
end