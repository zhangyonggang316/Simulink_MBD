function pos = saGetMousePosition
    mousePosition = get( 0, 'PointerLocation' );
    locationBase = get_param( gcs, 'Location' );
    scrollOffset = get_param( gcs, 'ScrollbarOffset' );
    screenSize = get( 0, 'ScreenSize' );
    zoomFactor = str2double( get_param( gcs, 'ZoomFactor' ) ) / 100;

    p_X = ceil( ( mousePosition( 1 ) - locationBase( 1 ) + scrollOffset( 1 ) ) / zoomFactor );
    p_Y = ceil( ( screenSize( 4 ) - mousePosition( 2 ) - locationBase( 2 ) + scrollOffset( 2 ) ) / zoomFactor );
    pos = [ p_X, p_Y ];
end