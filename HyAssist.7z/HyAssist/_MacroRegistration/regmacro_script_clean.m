function sam = regmacro_script_clean

    sam = saMacro( 'script_clean' );
    sam.Pattern = '^clean';
    sam.Callback = @script_clean;

end 

function [ actrec, success ] = script_clean( cmdstr, console )
    actrec = saRecorder;

    lns = saFindSystem( gcs, 'line_unconnected' );
    actrec.DeleteLine( lns );

    blocks = saFindSystem( gcs, 'block' );
    for i = 1:numel( blocks )
        lns = get_param( blocks( i ), 'LineHandles' );
        flds = fieldnames( lns );
        for kf = 1:numel( flds )
            tmplnhdls = lns.( flds{ kf } );
            if isempty( tmplnhdls ) || all( tmplnhdls < 0 )
                haveline = false;
            else 
                haveline = true;
                break;
            end 
        end 
        if ~haveline
            actrec.Dummy;
            delete( blocks( i ) );
        end 
    end 

    blocks = saFindSystem( gcs, 'block' );
    optstr = strtrim( regexprep( cmdstr, '^clean\s*', '', 'once' ) );
    for i = 1:numel( blocks )
        btobj = console.MapTo( blocks( i ) );
        actrec + btobj.ArrangePort( blocks( i ), optstr );
        actrec + btobj.Clean( blocks( i ) );
    end 
    success = true;
end