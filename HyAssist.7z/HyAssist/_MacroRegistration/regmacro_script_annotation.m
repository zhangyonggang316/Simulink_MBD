function sam = regmacro_script_annotation
    sam = saMacro( 'script_annotation' );
    sam.Pattern = '^anno';
    sam.Callback = @script_annotation;

end 

function [ actrec, success ] = script_annotation( cmdstr, console )
    actrec = saRecorder;
    success = false;
    optstr = strtrim( regexprep( cmdstr, '^anno\s*', '', 'once' ) );
    tgtobjs = saFindSystem( gcs, 'block' );
    if isempty( optstr )
        for i = 1:numel( tgtobjs )
            actrec + console.MapTo( tgtobjs( i ) ).Annotate( tgtobjs( i ) );
        end 
    else 
        for i = 1:numel( tgtobjs )
            if strcmp( optstr, '-' )
                actrec.SetParam( tgtobjs( i ), 'AttributesFormatString', '' );
            elseif strncmp( optstr, '+', 1 )
                oldanno = get_param( tgtobjs( i ), 'AttributesFormatString' );
                actrec.SetParam( tgtobjs( i ), 'AttributesFormatString', [ oldanno, optstr( 2:end  ) ] );
            else 
                actrec.SetParam( tgtobjs( i ), 'AttributesFormatString', optstr );
            end 
        end 
    end 
    success = true;
end
