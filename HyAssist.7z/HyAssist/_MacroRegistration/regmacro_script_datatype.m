%-------------------------------------------------------------------------------------------
%   �� �� ����regmacro_script_datatype.m
%   �ļ�������datatypeָ�����
%   ��    ����V1.0.1
%   �޸ļ�¼��
%            2022/07/23     xuhongjiang01    Boolean��������дָ��bool
%-------------------------------------------------------------------------------------------
function sam = regmacro_script_datatype
    sam = saMacro( 'setter_datatype' );
    sam.Pattern = '^(single|f32|double|f64|boolean|bool|b|uint8|u8|uint16|u16|uint32|u32|int8|s8|int16|s16|int32|s32)';
    sam.Callback = @setter_datatype;
end 

function [ actrec, success ] = setter_datatype( cmdstr, console )
    actrec = saRecorder;
    success = false;
    dt = strtrim( cmdstr );
    dt = saStandardDataTypeStr( dt );
    if ~isempty( dt )
        tgtobjs = saFindSystem( gcs, 'block' );
        for i = 1:numel( tgtobjs )
            actrec + console.MapTo( tgtobjs( i ) ).SetDataType( tgtobjs( i ), dt );
        end 
    end 
    success = true;
end