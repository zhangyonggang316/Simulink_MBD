function sam = regmacro_opsym_ampersand
    sam = saMacro( 'opsym_ampersand' );
    sam.Pattern = '&';
    sam.Callback = @opsym_ampersand;
    sam.Priority = 1;
end 

function [ actrec, success ] = opsym_ampersand( cmdstr, console )
    actrec = saRecorder;
    success = false;
    multicmdstrs = strtrim( regexp( cmdstr, '&', 'split' ) );
    if numel( multicmdstrs ) > 1
        for i = 1:numel( multicmdstrs )
            actrec + console.RunCommand( strtrim( multicmdstrs{ i } ) );
        end 
    end
    
    if ~isempty( actrec )
        success = true;
    end 
end