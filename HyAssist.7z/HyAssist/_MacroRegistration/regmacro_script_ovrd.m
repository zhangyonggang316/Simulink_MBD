%-------------------------------------------------------------------------------------------
%   �� �� ����regmacro_script_ovrd.m
%   �ļ�������ovrdָ�����
%   ��    ����V1.1.0
%   �޸ļ�¼��
%            2022/07/01     xuhongjiang01    �޸�Override���ƶ���
%            2022/07/08     xuhongjiang01    �޸�ԽȨʹ������ʶ�𷽷�����ԭstrsplit��Ϊfind
%                                            ���ⶨ�嵥λ������'_'ʱ��ȱ��һ�ε�λ����
%-------------------------------------------------------------------------------------------
function sam = regmacro_script_ovrd

    sam = saMacro( 'script_ovrd' );
    sam.Pattern = '^ovrd';
%     sam.Pattern = '^[sd]?ovrd';
%     sam.PromptMethod = { 'sovrd', 'ovrd', 'dovrd' };
    sam.Callback = @script_ovrd;

end 

function [ actrec, success ] = script_ovrd( cmdstr, console )
    actrec = saRecorder;
    success = false;
    rtsys = gcs;
    optstr = strtrim( regexprep( cmdstr, '^ovrd\s*', '', 'once' ) );
    lns = saFindSystem( rtsys, 'line' );
    ucpts = saFindSystem( rtsys, 'outport_unconnected' );

    WAITBARTHLD = 5;
    total = numel( lns ) + numel( ucpts );
    if total > WAITBARTHLD
    hwtbar = waitbar( 0, sprintf( 'Adding override block to ...' ) );
        showwtbar = true;
        wtbcntr = 0;
    else 
        showwtbar = false;
        wtbcntr = 0;
    end 

    swobj = console.MapTo( 'Switch' );
    cnstobj = console.MapTo( 'Constant' );
    option.PropagateString = false;
    option.AutoSize = true;
    option.GetMarginByMouse = false;
    for i = 1:numel( lns )
        if showwtbar
            wtbcntr = wtbcntr + 1;
            waitbar( wtbcntr / total, hwtbar, sprintf( 'Adding override block to line ...' ) );
        end 
        signame = console.GetUpstreamString( lns( i ) );
        
%         signameDst = console.GetDownstreamString( lns( i ) );
        
        %��������
        OvrdValName = [ signame, 'OvrdVal_P' ];
        
        underline = find(signame == '_',1,'first');  %�ҵ��׸��»���
        
        if ~isempty(underline)  %���»�������Ϊ��׼�淶����
            SigPrefix = signame(1:underline);
            SigDescr = signame(underline+1:end);
            
            for Idx=1:numel(SigDescr)
                if SigDescr(Idx) >= 'A' && SigDescr(Idx) <='Z'
                    OvrdName = [SigPrefix,'b',SigDescr(Idx:end),'Ovrd_P'];
                    break;
                else
                    continue;
                end
            end
            
        else
            OvrdName = ['b',signame,'Ovrd_P'];
        end        
        
        [ actrec2, swblk ] = swobj.InsertBlockToLine( lns( i ), [ 3, 1 ], option );
        actrec + actrec2;
        swpts = get_param( swblk, 'PortHandles' );
        actrec + cnstobj.AddBlockToPort( swpts.Inport( 1 ), option, 'Value', OvrdValName );
        actrec + cnstobj.AddBlockToPort( swpts.Inport( 2 ), option, 'Value', OvrdName );
    end
    
    for i = 1:numel( ucpts )
        if showwtbar
            wtbcntr = wtbcntr + 1;
            waitbar( wtbcntr / total, hwtbar, sprintf( 'Adding override block to unconnected port ...' ) );
        end 
        signame = console.GetUpstreamString( ucpts( i ) );
        
        %��������
        OvrdValName = [ signame, 'OvrdVal_P' ];
        
        underline = find(signame == '_',1,'first');  %�ҵ��׸��»���
        
        if ~isempty(underline)  %���»�������Ϊ��׼�淶����
            SigPrefix = signame(1:underline);
            SigDescr = signame(underline+1:end);
            
            for Idx=1:numel(SigDescr)
                if SigDescr(Idx) >= 'A' && SigDescr(Idx) <='Z'
                    OvrdName = [SigPrefix,'b',SigDescr(Idx:end),'Ovrd_P'];
                    break;
                else
                    continue;
                end
            end
            
        else
            OvrdName = ['b',signame,'Ovrd_P'];
        end        
        
        swobj.ConnectPort = [ 3, 1 ];
        [ actrec2, swblk ] = swobj.AddBlockToPort( ucpts( i ), option );
        actrec + actrec2;
        swobj.ConnectPort = [ 2, 1 ];
        swpts = get_param( swblk, 'PortHandles' );
        actrec + cnstobj.AddBlockToPort( swpts.Inport( 1 ), option, 'Value', OvrdValName );
        actrec + cnstobj.AddBlockToPort( swpts.Inport( 2 ), option, 'Value', OvrdName );
    end
    
    if showwtbar
        close( hwtbar );
    end 
    success = true;
end