function sam = regmacro_script_colorit

    sam = saMacro( 'script_colorit' );
    sam.Pattern = '^[bf]?color';
    sam.PromptMethod = { 'bcolor', 'color', 'fcolor', 'color==' };
    sam.Callback = @script_colorit;
    sam.Priority = 19;
    
end 

function [ actrec, success ] = script_colorit( cmdstr, console )
    actrec = saRecorder;
    success = false;
    rtsys = gcs;
    if cmdstr( 1 ) == 'b'
        bg = true;
    else 
        bg = false;
    end
    
    %������ɫ��ȡ
    optstr = strtrim( regexprep( cmdstr, '^[bf]?color\s*', '', 'once' ) );
    if ismember( optstr, { 'same', '=', '==' } )
        optstr = mat2str( rand( 1, 3 ) );
    elseif ismember( optstr, { 'black', 'Black'} )
        optstr = 'black';
    elseif ismember( optstr, { 'black', 'Black'} )
        optstr = 'black';
    elseif ismember( optstr, { 'w','white','W', 'White'} )
        optstr = 'white';
    elseif ismember( optstr, { 'r','red','R', 'Red'} )
        optstr = 'red';
    elseif ismember( optstr, { 'g','green','Green'} )
        optstr = 'green';
    elseif ismember( optstr, { 'blue','Blue'} )
        optstr = 'blue';
    elseif ismember( optstr, { 'c','cyan','C', 'Cyan'} )
        optstr = 'cyan';
    elseif ismember( optstr, { 'm','magenta','M', 'Magenta'} )
        optstr = 'magenta';
    elseif ismember( optstr, { 'y','yellow','Y', 'Yellow'} )
        optstr = 'yellow';
    elseif ismember( optstr, { 'gray','Gray'} )
        optstr = 'gray';
    elseif ismember( optstr, { 'lb','LB','lightblue','lightBlue','LightBlue'} )
        optstr = 'lightBlue';
    elseif ismember( optstr, { 'o','orange','O', 'Orange'} )
        optstr = 'orange';
    elseif ismember( optstr, { 'dg','DG','darkgreen','darkGreen', 'DarkGreen'} )
        optstr = 'darkGreen';
    else
        optstr = [];    %�����ȷʱ�����ÿգ�������ɫ����
    end
    
    TarBlks = saFindSystem( rtsys, 'block' );
    for i = 1:numel( TarBlks )
        if isempty( optstr )
%             rgb = mat2str( rand( 1, 3 ) );  %��ʱ���������ɫ�����ò���ȷʱ����ִ��
            rgb = optstr;
        else 
            rgb = optstr;
        end 
        if bg
            rgb = { [  ], rgb };
        end 
        btobj = console.MapTo( TarBlks( i ) );
        actrec + btobj.Color( TarBlks( i ), rgb );
        %��ʱ����ͬ����ģ����޸�
%         broblks = btobj.GetBroBlocks( TarBlks( i ) );
%         for k = 1:numel( broblks )
%             brobtobj = console.MapTo( broblks( k ) );
%             actrec + brobtobj.Color( broblks( k ), rgb );
%         end 
    end 
    success = true;
end 