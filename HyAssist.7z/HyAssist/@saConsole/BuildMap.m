function varargout = BuildMap( obj )
    pold = pwd;

    regmap = {  };
    p = mfilename( 'fullpath' );
    sepidx = strfind( p, filesep );
    regfolder = [ p( 1:sepidx( end  - 1 ) ), '_BlockRegistration' ];
    fs = what( regfolder );             %�г��ļ�����matlab�ļ���Ϣ�ṹ��
    regfs = [ fs.m, fs.p ];
    regfs_mat = fs.mat;
    regfs = regexprep( regfs, '\.(m|p)$', '' );
    cd( regfolder );

    protofls = regfs( strncmp( 'RegProtoBlk_', regfs, numel( 'RegProtoBlk_' ) ) );
    protos = [  ];
    for i = 1:numel( protofls )
        regobjs = eval( protofls{ i } );
        protos = [ protos;regobjs ];
    end 
    [ protos.Console ] = deal( obj );
    [ tmp, iprio ] = sort( [ protos.ProtoPriority ] );
    obj.ProtoBlocks = protos( iprio );


    regfs = setdiff( regfs, protofls );
    for i = 1:numel( regfs )
        regobjs = eval( regfs{ i } );
        for k = 1:numel( regobjs )
            if ~isempty( regobjs( k ).MapKey )
                regobjs( k ).Console = obj;
                if isempty( regmap ) || ~any( strcmp( regobjs( k ).MapKey, regmap( :, 1 ) ) )
                    regmap = [ regmap;{ regobjs( k ).MapKey, regobjs( k ) } ];
                else 
                    warning( 'SimAssist:ImportIgnore', 'Map key <%s> already exists in the list', regobjs( k ).MapKey );
                end 
            end 
        end 
    end 

    for i = 1:numel( regfs_mat )
        matbts = whos( '-file', regfs_mat{ i }, 'newer' );
        if ~isempty( matbts )
            load( regfs_mat{ i }, 'newer' );
            regobjs = newer;
            for k = 1:numel( regobjs )
                if ~isempty( regobjs( k ).MapKey )
                    if ~any( strcmp( regobjs( k ).MapKey, regmap( :, 1 ) ) )
                        regmap = [ regmap;{ regobjs( k ).MapKey, regobjs( k ) } ];
                    else 
                        warning( 'SimAssist:ImportIgnore', 'Map key <%s> already exists in the list', regobjs( k ).MapKey );
                    end 
                end 
            end 
        end 
    end 

    obj.BlockMap = regmap;

    routinemacros = [  ];
    for i = 1:numel( obj.ProtoBlocks )
        if ~isempty( obj.ProtoBlocks( i ).RoutinePattern )
            routinemacros = [ routinemacros;obj.ProtoBlocks( i ).CreateRoutineMacro ];
        end 
    end 
    btobjs = regmap( :, 2 );
    for i = 1:numel( btobjs )
        if ismember( btobjs{ i }.ObjectType, { 'block', 'protoblock' } ) && ~isempty( btobjs{ i }.RoutinePattern )
            routinemacros = [ routinemacros;btobjs{ i }.CreateRoutineMacro ];
        end 
    end 
    obj.Macros = [ obj.Macros;routinemacros ];

    cd( pold );
end