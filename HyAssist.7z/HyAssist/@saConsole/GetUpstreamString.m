function SrcStr = GetUpstreamString( obj, Hndl )

    if Hndl < 0         %����˿�δ����ʱ�����Ϊ-1����ʱ����ֱ���˳������û�ȡԴ�ַ���
        SrcStr = '';
        return
    end 

    if strcmp( get_param( Hndl, 'Type' ), 'block' )     %Դģ��Ϊblockʱ����Ҫ�ٴλ�ȡ��Ӧ����
        SrcStr = GetSrcStr_Block( obj, Hndl );
    elseif strcmp( get_param( Hndl, 'Type' ), 'line' )
        LineName = regexprep( get_param( Hndl, 'Name' ), '[<>]', '' ); %��ȡ�������������ʽ�滻�ַ�������������һ�ַ���<��>���滻�ɿ��ַ�����Ҫȥ��BusSelector������ϵ�<>
        if isempty( LineName )
            SrcPortHndl = get_param( Hndl, 'SrcPortHandle' );  %������ʱ����ȡԴ���������������Դ
            if SrcPortHndl < 0        
                SrcStr = '';
            else 
                SrcStr = obj.GetUpstreamString( SrcPortHndl );
            end 
        else 
            SrcStr = LineName;    %��������ֱ�ӷ����������˴���һ���⣬������Ŀ��ģ��ͬʱ��Ҫ����ʱ�����ܻᵼ������˿�������Ϊԭ��������Ҫ�������Σ���¼���⣬�����Ż�
        end 
    elseif strcmp( get_param( Hndl, 'Type' ), 'port' )  %Դģ��Ϊ�˿�portʱ����Ҫ�ٴλ�ȡ��Ӧ����
        SrcPortType = get_param( Hndl, 'PortType' );
%         if ismember( get_param( Hndl, 'PortType' ), { 'inport', 'trigger', 'enable' } )
        if ismember( SrcPortType, { 'inport', 'trigger', 'enable' } )
            PortLineHndl = get_param( Hndl, 'Line' );
            SrcStr = obj.GetUpstreamString( PortLineHndl ); 
        elseif strcmp( SrcPortType, 'outport' )
            SrcStr = GetSrcStr_Outport( obj, Hndl );
        else
            %Do nothing
        end 
    end 
end 

function thestr = GetSrcStr_Block( obj, blkhdl )
    blktyp = get_param( blkhdl, 'BlockType' );
    if ismember( blktyp, { 'Inport', 'EnablePort', 'TriggerPort' } )
        parblk = get_param( blkhdl, 'Parent' );
        parpts = get_param( parblk, 'PortHandles' );
        switch blktyp
            case 'Inport'
                ptnum = str2double( get_param( blkhdl, 'Port' ) );
                thestr = obj.GetUpstreamString( parpts.Inport( ptnum ) );
            case 'EnablePort'
                thestr = obj.GetUpstreamString( parpts.Enable );
            case 'TriggerPort'
                thestr = obj.GetUpstreamString( parpts.Trigger );
            otherwise 
        end 
    else 
        blkpts = get_param( blkhdl, 'PortHandles' );
        ninport = numel( blkpts.Inport );
        if ninport > 0
            thestr = cell( ninport, 1 );
            for i = 1:ninport
                thestr{ i } = obj.GetUpstreamString( blkpts.Inport( i ) );
            end 
            if ninport == 1
                thestr = thestr{ 1 };
            end 
        else 
            thestr = '';
        end 
    end 
end 

function thestr = GetSrcStr_Outport( obj, pthdl )
    parblk = get_param( get_param( pthdl, 'Parent' ), 'Handle' );
    blklns = get_param( parblk, 'LineHandles' );
    ppgtsig = get_param( pthdl, 'PropagatedSignals' );
    btobj = obj.MapTo( parblk );
    if isempty( btobj )
        thestr = '';
        return ;
    end 
    
    if ~isempty( ppgtsig ) && strcmpi( get_param( pthdl, 'ShowPropagatedSignals' ), 'on' )
        thestr = ppgtsig;
    else 
        if isempty( btobj.OutportStringMethod )
            if numel( blklns.Inport ) == 1
                ln_thru = blklns.Inport;
                thestr = obj.GetUpstreamString( ln_thru );
            else 
                thestr = get_param( parblk, 'Name' );
            end 
        elseif isa( btobj.OutportStringMethod, 'function_handle' )
            n_arg = nargin( btobj.OutportStringMethod );
            if n_arg == 1
                thestr = btobj.OutportStringMethod( pthdl );
            else 
                appdata = struct( 'Console', obj, 'saObject', btobj );
                thestr = btobj.OutportStringMethod( pthdl, appdata );
            end 
        elseif isstr( btobj.OutportStringMethod )
            objpars = get_param( parblk, 'ObjectParameters' );
            if isfield( objpars, btobj.OutportStringMethod )
                thestr = get_param( parblk, btobj.OutportStringMethod );
            else 
                thestr = btobj.OutportStringMethod;
            end 
        elseif isnumeric( btobj.OutportStringMethod ) && btobj.OutportStringMethod > 0
            ln_thru = blklns.Inport( min( btobj.OutportStringMethod, end  ) );
            thestr = obj.GetUpstreamString( ln_thru );
        else 
            thestr = '';
        end 
    end 
    if iscellstr( thestr )
        thestr = thestr{ 1 };
    end 
    if isempty( thestr )
        thestr = get_param( parblk, 'Name' );
    end 

end 
