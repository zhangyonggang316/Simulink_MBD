function [ sabt, sam ] = AddCurrentBlockToMap( obj, BlkHndl )

    [ sabt, sam ] = create_saobject( rawtxt{ i, : } );
    sabt.Console = obj;
    obj.Map( sabt.MapKey ) = sabt;
    sam.Console = obj;

    [ tmp, iprio ] = sort( [ macroobjs.Priority ] );
    macroobjs = macroobjs( iprio );
    obj.Macros = macroobjs;
end 


function [ sabt, sam ] = create_saobject( varargin )
    [ msktyp, pattern, srcpath, priority ] = varargin{ 1:4 };
    DlgParas = get_param( srcpath, 'DialogParameters' );
    if ~isempty( DlgParas )
        DlgParas = fieldnames( DlgParas );
    else 
        DlgParas = {  };
    end 
    blktyp = get_param( srcpath, 'BlockType' );

    sabt = saBlock( blktyp, msktyp, srcpath );
    if ~isempty( DlgParas )
        sabt.MajorProperty = DlgParas{ 1 };
    end 

    sam = saMacroAdder( sabt, pattern );
    sam.Priority = priority;
end
