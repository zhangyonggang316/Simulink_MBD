function objs = SplitToIntactBGs( obj )
    objs = [  ];
    if obj.BlockCount == 0
        return;
    end 
    blkset = obj.BlockHandles;
    resid = blkset;
    while ~isempty( resid )
        subbg = resid( 1 );
        expdedblks = resid( 1 );
        while ~isempty( expdedblks )
            adjblkspool = [  ];
            for i = 1:numel( expdedblks )
                tmpadjblks = GetAdjBlks( expdedblks( i ) );
                adjblkspool = [ adjblkspool;tmpadjblks.SrcBlockHandles;tmpadjblks.DstBlockHandles ];
            end 
            expdedblks = intersect( adjblkspool, resid );
            subbg = [ subbg;expdedblks ];
            resid = setdiff( resid, subbg );
        end 
        objs = [ objs;saBlockGroup( subbg ) ];
    end 
end