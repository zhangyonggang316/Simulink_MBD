function actrec = set_pos_align( blkhdl, newpos )

end